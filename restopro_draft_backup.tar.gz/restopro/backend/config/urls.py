from django.contrib import admin
from django.urls import path, include
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView, SpectacularRedocView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/v1/auth/', include('apps.accounts.urls')),
    path('api/v1/tenancy/', include('apps.tenancy.urls')),
    path('api/v1/menu/', include('apps.menu.urls')),
    path('api/v1/floor/', include('apps.floor.urls')),
    path('api/v1/orders/', include('apps.orders.urls')),
    path('api/v1/sales/', include('apps.sales.urls')),

    # Swagger / OpenAPI documentation
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
]

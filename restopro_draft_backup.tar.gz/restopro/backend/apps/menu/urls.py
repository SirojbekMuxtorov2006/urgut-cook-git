from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.menu.views import (
    CategoryViewSet,
    MenuItemViewSet,
    KitchenStationViewSet,
    StopListViewSet,
    PriceTypeViewSet,
    ComboViewSet,
)

router = DefaultRouter()
router.register('categories', CategoryViewSet, basename='category')
router.register('items', MenuItemViewSet, basename='menu-item')
router.register('stations', KitchenStationViewSet, basename='kitchen-station')
router.register('stop-list', StopListViewSet, basename='stop-list')
router.register('price-types', PriceTypeViewSet, basename='price-type')
router.register('combos', ComboViewSet, basename='combo')

urlpatterns = [
    path('', include(router.urls)),
]

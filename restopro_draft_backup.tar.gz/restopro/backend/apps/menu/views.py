import decimal
from rest_framework import serializers, viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from apps.menu.models import (
    Category,
    MenuItem,
    MenuItemVariant,
    ModifierGroup,
    Modifier,
    KitchenStation,
    StopList,
    PriceType,
    Combo,
    ComboItem,
    PriceHistory,
)
from apps.menu.services import MenuService

class ModifierSerializer(serializers.ModelSerializer):
    class Meta:
        model = Modifier
        fields = ['id', 'name', 'price']


class ModifierGroupSerializer(serializers.ModelSerializer):
    modifiers = ModifierSerializer(many=True, read_only=True)

    class Meta:
        model = ModifierGroup
        fields = ['id', 'name', 'is_required', 'min_select', 'max_select', 'modifiers']


class MenuItemVariantSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuItemVariant
        fields = ['id', 'name', 'price', 'is_default']


class MenuItemSerializer(serializers.ModelSerializer):
    variants = MenuItemVariantSerializer(many=True, read_only=True)
    category_name = serializers.CharField(source='category.name_uz', read_only=True)
    station_name = serializers.CharField(source='kitchen_station.name', read_only=True)

    class Meta:
        model = MenuItem
        fields = [
            'id', 'category', 'category_name', 'kitchen_station', 'station_name',
            'name_uz', 'name_ru', 'description', 'image_url', 'price',
            'cost_price', 'unit', 'cooking_time_minutes', 'is_available',
            'is_popular', 'variants'
        ]


class CategorySerializer(serializers.ModelSerializer):
    items_count = serializers.IntegerField(source='items.count', read_only=True)

    class Meta:
        model = Category
        fields = ['id', 'name_uz', 'name_ru', 'icon', 'color', 'sort_order', 'is_active', 'items_count']


class KitchenStationSerializer(serializers.ModelSerializer):
    class Meta:
        model = KitchenStation
        fields = ['id', 'name', 'printer_ip', 'is_active']


class StopListSerializer(serializers.ModelSerializer):
    menu_item_name = serializers.CharField(source='menu_item.name_uz', read_only=True)
    price = serializers.DecimalField(source='menu_item.price', max_digits=14, decimal_places=2, read_only=True)

    class Meta:
        model = StopList
        fields = ['id', 'menu_item', 'menu_item_name', 'price', 'reason', 'created_at']


class PriceTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = PriceType
        fields = ['id', 'name', 'code', 'is_default', 'markup_percent', 'is_active']


class ComboItemSerializer(serializers.ModelSerializer):
    item_name = serializers.CharField(source='menu_item.name_uz', read_only=True)

    class Meta:
        model = ComboItem
        fields = ['id', 'menu_item', 'item_name', 'quantity']


class ComboSerializer(serializers.ModelSerializer):
    items = ComboItemSerializer(many=True, read_only=True)

    class Meta:
        model = Combo
        fields = ['id', 'name_uz', 'name_ru', 'description', 'price', 'start_time', 'end_time', 'days_of_week', 'is_active', 'items']


class CategoryViewSet(viewsets.ModelViewSet):
    serializer_class = CategorySerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Category.objects.filter(is_active=True).prefetch_related('items')

    def perform_create(self, serializer):
        serializer.save(company=self.request.user.company, branch=self.request.user.branch)


class MenuItemViewSet(viewsets.ModelViewSet):
    serializer_class = MenuItemSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = MenuItem.objects.all().prefetch_related('variants')
        category_id = self.request.query_params.get('category_id')
        if category_id:
            qs = qs.filter(category_id=category_id)
        return qs

    def perform_create(self, serializer):
        serializer.save(company=self.request.user.company, branch=self.request.user.branch)

    @action(methods=['post'], detail=True, url_path='toggle-stop')
    def toggle_stop(self, request, pk=None):
        is_stopped = request.data.get('is_stopped', True)
        reason = request.data.get('reason', '')
        result = MenuService.toggle_stop_list(
            menu_item_id=pk,
            is_stopped=is_stopped,
            reason=reason,
            user=request.user
        )
        return Response(result)

    @action(methods=['post'], detail=True, url_path='update-price')
    def update_price(self, request, pk=None):
        new_price = decimal.Decimal(str(request.data.get('price')))
        new_cost = request.data.get('cost_price')
        if new_cost is not None:
            new_cost = decimal.Decimal(str(new_cost))
        reason = request.data.get('reason', 'Menejer tomonidan narx o\'zgartirildi')

        item = MenuService.update_item_price(
            menu_item_id=pk,
            new_price=new_price,
            new_cost_price=new_cost,
            user=request.user,
            reason=reason
        )
        return Response(MenuItemSerializer(item).data)

    @action(methods=['post'], detail=False, url_path='copy-to-branch')
    def copy_to_branch(self, request):
        source_id = request.data.get('source_branch_id')
        target_id = request.data.get('target_branch_id')
        if not source_id or not target_id:
            return Response({'error': 'source_branch_id va target_branch_id kiritilishi shart'}, status=status.HTTP_400_BAD_REQUEST)
        result = MenuService.copy_menu_to_branch(source_id, target_id)
        return Response(result)


class StopListViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = StopListSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return StopList.objects.select_related('menu_item').all()


class PriceTypeViewSet(viewsets.ModelViewSet):
    serializer_class = PriceTypeSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return PriceType.objects.filter(is_active=True)

    def perform_create(self, serializer):
        serializer.save(company=self.request.user.company, branch=self.request.user.branch)


class ComboViewSet(viewsets.ModelViewSet):
    serializer_class = ComboSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Combo.objects.filter(is_active=True).prefetch_related('items')

    def perform_create(self, serializer):
        serializer.save(company=self.request.user.company, branch=self.request.user.branch)


class KitchenStationViewSet(viewsets.ModelViewSet):
    serializer_class = KitchenStationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return KitchenStation.objects.filter(is_active=True)

    def perform_create(self, serializer):
        serializer.save(company=self.request.user.company, branch=self.request.user.branch)

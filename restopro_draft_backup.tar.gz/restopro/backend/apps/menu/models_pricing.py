import decimal
from django.db import models
from apps.common.models import TenantBaseModel
from apps.menu.models import MenuItem

class PriceType(TenantBaseModel):
    class TypeCode(models.TextChoices):
        DINE_IN = 'DINE_IN', 'Zalda o\'tirish (Standart)'
        TAKEAWAY = 'TAKEAWAY', 'Olib ketish (Takeaway)'
        DELIVERY = 'DELIVERY', 'Yetkazib berish (Delivery)'
        HAPPY_HOUR = 'HAPPY_HOUR', 'Happy Hour (Aksiya)'

    name = models.CharField(max_length=100)
    code = models.CharField(max_length=50, choices=TypeCode.choices, default=TypeCode.DINE_IN)
    is_default = models.BooleanField(default=False)
    markup_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0.0) # foiz ustama yoki chegirma
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Narx turi"
        verbose_name_plural = "Narx turlari"

    def __str__(self):
        return f"{self.name} ({self.code})"


class MenuItemPrice(TenantBaseModel):
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name='custom_prices')
    price_type = models.ForeignKey(PriceType, on_delete=models.CASCADE, related_name='item_prices')
    price = models.DecimalField(max_digits=14, decimal_places=2)

    class Meta:
        unique_together = ('company', 'branch', 'menu_item', 'price_type')
        verbose_name = "Maxsus narx"
        verbose_name_plural = "Maxsus narxlar"


class PriceHistory(TenantBaseModel):
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name='price_history')
    old_price = models.DecimalField(max_digits=14, decimal_places=2)
    new_price = models.DecimalField(max_digits=14, decimal_places=2)
    old_cost_price = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    new_cost_price = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    changed_by_name = models.CharField(max_length=150, blank=True)
    reason = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ['-created_at']


class Combo(TenantBaseModel):
    name_uz = models.CharField(max_length=255)
    name_ru = models.CharField(max_length=255, blank=True)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=14, decimal_places=2)
    start_time = models.TimeField(null=True, blank=True) # Masalan: 12:00
    end_time = models.TimeField(null=True, blank=True)   # Masalan: 15:00 (Biznes lanch)
    days_of_week = models.JSONField(default=list) # [1, 2, 3, 4, 5] dushanba-juma
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Kombo: {self.name_uz} - {self.price:,.0f} so'm"


class ComboItem(TenantBaseModel):
    combo = models.ForeignKey(Combo, on_delete=models.CASCADE, related_name='items')
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.combo.name_uz} -> {self.quantity}x {self.menu_item.name_uz}"

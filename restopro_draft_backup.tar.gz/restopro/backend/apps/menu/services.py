import decimal
from django.db import transaction
from django.utils import timezone
from apps.menu.models import (
    Category,
    MenuItem,
    MenuItemVariant,
    ModifierGroup,
    Modifier,
    StopList,
    PriceHistory,
    PriceType,
    MenuItemPrice,
)
from apps.tenancy.models import Branch

class MenuService:
    @staticmethod
    @transaction.atomic
    def toggle_stop_list(menu_item_id: str, is_stopped: bool, reason: str = "", user=None) -> dict:
        """
        Taomni stop-listga kiritish yoki chiqarish.
        Stop-listga tushganda barcha kassalarga, ofitsiantlarga va QR menyuga signal yuboriladi.
        """
        item = MenuItem.objects.select_for_update().get(id=menu_item_id)
        
        if is_stopped:
            item.is_available = False
            item.save(update_fields=['is_available'])
            stop_record, _ = StopList.objects.update_or_create(
                menu_item=item,
                defaults={
                    'company': item.company,
                    'branch': item.branch,
                    'reason': reason,
                    'auto_resume_date': None,
                }
            )
            action = "STOP_ADDED"
        else:
            item.is_available = True
            item.save(update_fields=['is_available'])
            StopList.objects.filter(menu_item=item).delete()
            action = "STOP_REMOVED"

        # Channels realtime signali yuborish (WebSocket)
        try:
            from asgiref.sync import async_to_sync
            from channels.layers import get_channel_layer
            channel_layer = get_channel_layer()
            if channel_layer:
                async_to_sync(channel_layer.group_send)(
                    f"company_{item.company_id}",
                    {
                        "type": "stoplist.changed",
                        "menu_item_id": str(item.id),
                        "menu_item_name": item.name_uz,
                        "is_available": item.is_available,
                        "reason": reason,
                    }
                )
        except Exception:
            pass

        return {
            "menu_item_id": str(item.id),
            "name_uz": item.name_uz,
            "is_available": item.is_available,
            "action": action,
            "reason": reason,
        }

    @staticmethod
    @transaction.atomic
    def update_item_price(menu_item_id: str, new_price: decimal.Decimal, new_cost_price: decimal.Decimal = None, user=None, reason: str = "") -> MenuItem:
        """
        Taom narxini o'zgartirish va tarixini PriceHistory jadvaliga saqlash.
        """
        item = MenuItem.objects.select_for_update().get(id=menu_item_id)
        old_price = item.price
        old_cost = item.cost_price

        item.price = new_price
        if new_cost_price is not None:
            item.cost_price = new_cost_price
        item.save(update_fields=['price', 'cost_price', 'updated_at'])

        # Tarix yaratish
        PriceHistory.objects.create(
            company=item.company,
            branch=item.branch,
            menu_item=item,
            old_price=old_price,
            new_price=new_price,
            old_cost_price=old_cost,
            new_cost_price=item.cost_price,
            changed_by_name=user.full_name if user else "Tizim",
            reason=reason,
        )
        return item

    @staticmethod
    @transaction.atomic
    def copy_menu_to_branch(source_branch_id: str, target_branch_id: str) -> dict:
        """
        Bir filialdagi butun menyuni (kategoriyalar, taomlar, variantlar, modifierlar)
        ikkinchi yangi filialga nusxalash.
        """
        source_branch = Branch.objects.get(id=source_branch_id)
        target_branch = Branch.objects.get(id=target_branch_id)

        categories = Category.objects.filter(branch=source_branch, is_active=True)
        copied_categories = 0
        copied_items = 0

        for cat in categories:
            new_cat, _ = Category.objects.update_or_create(
                company=target_branch.company,
                branch=target_branch,
                name_uz=cat.name_uz,
                defaults={
                    'name_ru': cat.name_ru,
                    'icon': cat.icon,
                    'color': cat.color,
                    'sort_order': cat.sort_order,
                    'is_active': True,
                }
            )
            copied_categories += 1

            for item in cat.items.filter(is_available=True):
                new_item, _ = MenuItem.objects.update_or_create(
                    company=target_branch.company,
                    branch=target_branch,
                    category=new_cat,
                    name_uz=item.name_uz,
                    defaults={
                        'name_ru': item.name_ru,
                        'description': item.description,
                        'image_url': item.image_url,
                        'price': item.price,
                        'cost_price': item.cost_price,
                        'unit': item.unit,
                        'cooking_time_minutes': item.cooking_time_minutes,
                        'is_available': True,
                    }
                )
                copied_items += 1

                # Variantlarni nusxalash
                for v in item.variants.all():
                    MenuItemVariant.objects.update_or_create(
                        company=target_branch.company,
                        branch=target_branch,
                        menu_item=new_item,
                        name=v.name,
                        defaults={
                            'price': v.price,
                            'is_default': v.is_default,
                        }
                    )

        return {
            "source_branch": source_branch.name,
            "target_branch": target_branch.name,
            "copied_categories": copied_categories,
            "copied_items": copied_items,
        }

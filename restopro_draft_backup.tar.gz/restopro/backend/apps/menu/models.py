from django.db import models
from apps.common.models import TenantBaseModel

class KitchenStation(TenantBaseModel):
    name = models.CharField(max_length=100, verbose_name="Sex nomi")
    printer_ip = models.GenericIPAddressField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Oshxona sexi"
        verbose_name_plural = "Oshxona sexlari"

    def __str__(self):
        return self.name


class Category(TenantBaseModel):
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='subcategories')
    name_uz = models.CharField(max_length=150)
    name_ru = models.CharField(max_length=150, blank=True)
    icon = models.CharField(max_length=50, default="utensils")
    color = models.CharField(max_length=20, default="#f97316")
    sort_order = models.PositiveIntegerField(default=1)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Kategoriya"
        verbose_name_plural = "Kategoriyalar"
        ordering = ['sort_order', 'name_uz']

    def __str__(self):
        return self.name_uz


class UnitType(models.TextChoices):
    PORTION = 'PORTION', 'Porsiya'
    KG = 'KG', 'Kilogramm (kg)'
    GRAM = 'GRAM', 'Gramm (g)'
    PIECE = 'PIECE', 'Dona'
    LITER = 'LITER', 'Litr'


class MenuItem(TenantBaseModel):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='items')
    kitchen_station = models.ForeignKey(KitchenStation, on_delete=models.SET_NULL, null=True, blank=True, related_name='items')
    name_uz = models.CharField(max_length=255)
    name_ru = models.CharField(max_length=255, blank=True)
    description = models.TextField(blank=True)
    image_url = models.URLField(max_length=500, blank=True, null=True)
    price = models.DecimalField(max_digits=14, decimal_places=2, verbose_name="Sotuv narxi (so'm)")
    cost_price = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="Tannarxi (so'm)")
    unit = models.CharField(max_length=20, choices=UnitType.choices, default=UnitType.PORTION)
    cooking_time_minutes = models.PositiveIntegerField(default=15)
    is_available = models.BooleanField(default=True)
    is_popular = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Taom / Ichimlik"
        verbose_name_plural = "Taomlar va Ichimliklar"

    def __str__(self):
        return f"{self.name_uz} - {self.price:,.0f} so'm"


class MenuItemVariant(TenantBaseModel):
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name='variants')
    name = models.CharField(max_length=100) # Masalan: 0.5 pors, 1 pors, 1 kg
    price = models.DecimalField(max_digits=14, decimal_places=2)
    is_default = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.menu_item.name_uz} ({self.name}) - {self.price:,.0f} so'm"


class ModifierGroup(TenantBaseModel):
    name = models.CharField(max_length=150) # Masalan: Qo'shimchalar, Non turi
    is_required = models.BooleanField(default=False)
    min_select = models.PositiveIntegerField(default=0)
    max_select = models.PositiveIntegerField(default=5)

    def __str__(self):
        return self.name


class Modifier(TenantBaseModel):
    group = models.ForeignKey(ModifierGroup, on_delete=models.CASCADE, related_name='modifiers')
    name = models.CharField(max_length=150) # Masalan: +Qazi, +Bedana tuxumi
    price = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    def __str__(self):
        return f"{self.name} (+{self.price:,.0f} so'm)"


class StopList(TenantBaseModel):
    menu_item = models.OneToOneField(MenuItem, on_delete=models.CASCADE, related_name='stop_record')
    reason = models.CharField(max_length=255, blank=True)
    auto_resume_date = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"STOP: {self.menu_item.name_uz}"

from apps.menu.models_pricing import PriceType, MenuItemPrice, PriceHistory, Combo, ComboItem

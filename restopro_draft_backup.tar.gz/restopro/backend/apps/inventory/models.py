from django.db import models
from apps.common.models import TenantBaseModel
from apps.menu.models import MenuItem

class Ingredient(TenantBaseModel):
    name = models.CharField(max_length=150, verbose_name="Xomashyo nomi")
    unit = models.CharField(max_length=20, default="kg") # kg, litr, dona, gramm
    current_stock = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    min_stock = models.DecimalField(max_digits=14, decimal_places=3, default=5)
    cost_price = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="1 birlik narxi (so'm)")
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Xomashyo / Masalliq"
        verbose_name_plural = "Xomashyolar va Masalliqlar"

    def __str__(self):
        return f"{self.name} ({self.current_stock} {self.unit})"


class TechCard(TenantBaseModel):
    menu_item = models.OneToOneField(MenuItem, on_delete=models.CASCADE, related_name='tech_card')
    yield_amount = models.DecimalField(max_digits=10, decimal_places=2, default=1.0) # 1 porsiya chiqishi
    description = models.TextField(blank=True)

    class Meta:
        verbose_name = "Texnologik karta (Retsept)"
        verbose_name_plural = "Texnologik kartalar (Retseptlar)"

    def __str__(self):
        return f"Retsept: {self.menu_item.name_uz}"


class TechCardItem(TenantBaseModel):
    tech_card = models.ForeignKey(TechCard, on_delete=models.CASCADE, related_name='items')
    ingredient = models.ForeignKey(Ingredient, on_delete=models.CASCADE, related_name='tech_card_items')
    gross_weight = models.DecimalField(max_digits=10, decimal_places=3, verbose_name="Brutto (chiqindi bilan)")
    net_weight = models.DecimalField(max_digits=10, decimal_places=3, verbose_name="Netto (tozalangan)")
    waste_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0.0)

    def __str__(self):
        return f"{self.ingredient.name} -> {self.gross_weight} {self.ingredient.unit}"


class StockMovementType(models.TextChoices):
    PURCHASE = 'PURCHASE', 'Kirim (Xarid)'
    SALE_RECIPE = 'SALE_RECIPE', 'Sotuv chiqimi (Retsept bo\'yicha)'
    WRITE_OFF = 'WRITE_OFF', 'Hisobdan chiqarish (Isrof)'
    TRANSFER = 'TRANSFER', 'Ichki ko\'chirish'
    INVENTORY = 'INVENTORY', 'Inventarizatsiya farqi'


class StockMovement(TenantBaseModel):
    ingredient = models.ForeignKey(Ingredient, on_delete=models.CASCADE, related_name='movements')
    movement_type = models.CharField(max_length=30, choices=StockMovementType.choices)
    quantity = models.DecimalField(max_digits=14, decimal_places=3) # musbat yoki manfiy
    unit_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    reference_id = models.CharField(max_length=100, blank=True, null=True) # order_id yoki doc_id
    notes = models.TextField(blank=True)

    class Meta:
        verbose_name = "Ombor harakati"
        verbose_name_plural = "Ombor harakatlari (Ledger)"
        ordering = ['-created_at']

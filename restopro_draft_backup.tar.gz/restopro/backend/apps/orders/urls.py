from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.orders.views import OrderViewSet, KitchenTicketViewSet

router = DefaultRouter()
router.register('orders', OrderViewSet, basename='order')
router.register('kitchen-tickets', KitchenTicketViewSet, basename='kitchen-ticket')

urlpatterns = [
    path('', include(router.urls)),
]

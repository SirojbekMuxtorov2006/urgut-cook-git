import decimal
from django.db import models
from django.conf import settings
from apps.common.models import TenantBaseModel
from apps.floor.models import Table
from apps.menu.models import MenuItem, MenuItemVariant, Modifier, KitchenStation

class OrderType(models.TextChoices):
    DINE_IN = 'DINE_IN', 'Zalda o\'tirish'
    TAKEAWAY = 'TAKEAWAY', 'Olib ketish'
    DELIVERY = 'DELIVERY', 'Yetkazib berish'
    BANQUET = 'BANQUET', 'Banket'


class OrderStatus(models.TextChoices):
    NEW = 'NEW', 'Yangi'
    SENT_TO_KITCHEN = 'SENT_TO_KITCHEN', 'Oshxonaga yuborildi'
    COOKING = 'COOKING', 'Tayyorlanmoqda'
    READY = 'READY', 'Tayyor'
    SERVED = 'SERVED', 'Yetkazildi'
    PAID = 'PAID', 'To\'landi (Yopildi)'
    CANCELLED = 'CANCELLED', 'Bekor qilindi'


class Order(TenantBaseModel):
    order_number = models.CharField(max_length=64, db_index=True, verbose_name="Buyurtma №")
    order_type = models.CharField(max_length=30, choices=OrderType.choices, default=OrderType.DINE_IN)
    status = models.CharField(max_length=30, choices=OrderStatus.choices, default=OrderStatus.NEW, db_index=True)
    table = models.ForeignKey(Table, on_delete=models.SET_NULL, null=True, blank=True, related_name='orders')
    waiter = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='waiter_orders'
    )
    guests_count = models.PositiveIntegerField(default=1)
    
    # Moliyaviy hisob-kitob (DecimalField, Float taqiqlangan)
    subtotal = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="Taomlar summasi")
    service_fee_percent = models.DecimalField(max_digits=5, decimal_places=2, default=10.0, verbose_name="Xizmat foizi")
    service_fee_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="Xizmat summasi")
    discount_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0.0)
    discount_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="Jami to'lov summasi")
    
    paid_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    tip_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="Choychaqa")
    
    notes = models.TextField(blank=True, verbose_name="Izoh")
    is_precheck_printed = models.BooleanField(default=False)
    opened_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Buyurtma"
        verbose_name_plural = "Buyurtmalar"
        ordering = ['-opened_at']

    def __str__(self):
        return f"Buyurtma #{self.order_number} ({self.get_status_display()}) - {self.total_amount:,.0f} so'm"


class OrderItemStatus(models.TextChoices):
    NEW = 'NEW', 'Yangi'
    SENT = 'SENT', 'Oshxonaga yuborildi'
    COOKING = 'COOKING', 'Tayyorlanmoqda'
    READY = 'READY', 'Tayyor'
    SERVED = 'SERVED', 'Yetkazildi'
    VOIDED = 'VOIDED', 'Bekor qilindi (Isrof)'


class OrderItem(TenantBaseModel):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    menu_item = models.ForeignKey(MenuItem, on_delete=models.PROTECT)
    variant = models.ForeignKey(MenuItemVariant, on_delete=models.SET_NULL, null=True, blank=True)
    
    dish_name = models.CharField(max_length=255) # Muzlatilgan nom
    unit_price = models.DecimalField(max_digits=14, decimal_places=2) # Muzlatilgan narx
    cost_price = models.DecimalField(max_digits=14, decimal_places=2, default=0) # Muzlatilgan tannarx
    quantity = models.PositiveIntegerField(default=1)
    total_price = models.DecimalField(max_digits=14, decimal_places=2)
    
    course_number = models.PositiveIntegerField(default=1, verbose_name="Kurs (1-salat, 2-issiq)")
    seat_number = models.PositiveIntegerField(default=1, verbose_name="Mehmon o'rindiq raqami")
    kitchen_station = models.ForeignKey(KitchenStation, on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=30, choices=OrderItemStatus.choices, default=OrderItemStatus.NEW)
    notes = models.CharField(max_length=255, blank=True)
    
    void_reason = models.CharField(max_length=255, blank=True, null=True)
    voided_by_name = models.CharField(max_length=150, blank=True, null=True)
    voided_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.quantity}x {self.dish_name} ({self.total_price:,.0f} so'm)"


class OrderItemModifier(TenantBaseModel):
    order_item = models.ForeignKey(OrderItem, on_delete=models.CASCADE, related_name='modifiers')
    modifier = models.ForeignKey(Modifier, on_delete=models.PROTECT)
    name = models.CharField(max_length=150)
    price = models.DecimalField(max_digits=14, decimal_places=2)

    def __str__(self):
        return f"+{self.name} ({self.price:,.0f} so'm)"


class KitchenTicket(TenantBaseModel):
    class TicketType(models.TextChoices):
        NEW_ORDER = 'NEW_ORDER', 'Yangi buyurtma'
        ITEM_VOID = 'ITEM_VOID', 'Bekor qilish (Isrof)'
        URGENT = 'URGENT', 'Shoshilinch'

    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='kitchen_tickets')
    station = models.ForeignKey(KitchenStation, on_delete=models.CASCADE)
    ticket_type = models.CharField(max_length=30, choices=TicketType.choices, default=TicketType.NEW_ORDER)
    ticket_number = models.CharField(max_length=50)
    payload = models.JSONField(default=dict) # Taomlar, kurs, stol, ofitsiant
    is_printed = models.BooleanField(default=False)
    printed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Sex chiptasi #{self.ticket_number} - {self.station.name}"

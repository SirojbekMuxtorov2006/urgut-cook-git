import decimal
import uuid
from datetime import datetime
from django.db import transaction
from django.utils import timezone
from django.contrib.auth.hashers import check_password
from rest_framework.exceptions import ValidationError, PermissionDenied

from apps.orders.models import Order, OrderItem, OrderItemModifier, KitchenTicket, OrderStatus, OrderItemStatus
from apps.sales.models import Shift, Payment, Receipt, CashOperation, ReceiptType, PaymentMethod
from apps.floor.models import Table, TableStatus
from apps.menu.models import MenuItem, MenuItemVariant, Modifier
from apps.accounts.models import User, UserRole
from apps.printing.engine import EscPosReceiptBuilder

class OrderService:
    @staticmethod
    @transaction.atomic
    def create_order(
        company,
        branch,
        order_type: str,
        table_id: str = None,
        waiter=None,
        guests_count: int = 1,
        notes: str = ""
    ) -> Order:
        today_str = timezone.now().strftime("%Y%m%d")
        orders_today_count = Order.objects.filter(company=company, opened_at__date=timezone.now().date()).count() + 1
        order_number = f"ORD-{today_str}-{orders_today_count:04d}"

        table = None
        if table_id:
            table = Table.objects.select_for_update().get(id=table_id, company=company)
            table.status = TableStatus.OCCUPIED
            table.save(update_fields=['status'])

        order = Order.objects.create(
            company=company,
            branch=branch,
            order_number=order_number,
            order_type=order_type,
            table=table,
            waiter=waiter,
            guests_count=guests_count,
            service_fee_percent=branch.service_fee_percent if branch else decimal.Decimal('10.0'),
            notes=notes,
        )
        return order

    @staticmethod
    @transaction.atomic
    def add_items_to_order(order_id: str, items_data: list) -> Order:
        """
        Buyurtmaga taomlar qo'shish va summalarni qayta hisoblash.
        """
        order = Order.objects.select_for_update().get(id=order_id)
        if order.status in [OrderStatus.PAID, OrderStatus.CANCELLED]:
            raise ValidationError("Yopilgan yoki bekor qilingan buyurtmaga taom qo'shib bo'lmaydi")

        for item_dict in items_data:
            menu_item = MenuItem.objects.get(id=item_dict['menu_item_id'])
            variant = None
            unit_price = menu_item.price
            cost_price = menu_item.cost_price

            if item_dict.get('variant_id'):
                variant = MenuItemVariant.objects.get(id=item_dict['variant_id'])
                unit_price = variant.price

            quantity = int(item_dict.get('quantity', 1))
            modifiers_sum = decimal.Decimal('0.0')

            order_item = OrderItem.objects.create(
                company=order.company,
                branch=order.branch,
                order=order,
                menu_item=menu_item,
                variant=variant,
                dish_name=f"{menu_item.name_uz}{f' ({variant.name})' if variant else ''}",
                unit_price=unit_price,
                cost_price=cost_price,
                quantity=quantity,
                total_price=unit_price * quantity,
                course_number=int(item_dict.get('course_number', 1)),
                seat_number=int(item_dict.get('seat_number', 1)),
                kitchen_station=menu_item.kitchen_station,
                notes=item_dict.get('notes', ''),
            )

            # Modifierlar
            for mod_id in item_dict.get('modifier_ids', []):
                mod = Modifier.objects.get(id=mod_id)
                OrderItemModifier.objects.create(
                    company=order.company,
                    branch=order.branch,
                    order_item=order_item,
                    modifier=mod,
                    name=mod.name,
                    price=mod.price,
                )
                modifiers_sum += mod.price * quantity

            if modifiers_sum > 0:
                order_item.total_price += modifiers_sum
                order_item.save(update_fields=['total_price'])

        OrderService._recalculate_totals(order)
        return order

    @staticmethod
    def _recalculate_totals(order: Order):
        active_items = order.items.exclude(status=OrderItemStatus.VOIDED)
        subtotal = sum((item.total_price for item in active_items), decimal.Decimal('0.0'))
        
        service_fee = decimal.Decimal('0.0')
        if order.service_fee_percent > 0:
            service_fee = (subtotal * order.service_fee_percent) / decimal.Decimal('100.0')

        total = subtotal + service_fee - order.discount_amount
        if total < 0:
            total = decimal.Decimal('0.0')

        order.subtotal = subtotal
        order.service_fee_amount = service_fee
        order.total_amount = total
        order.save(update_fields=['subtotal', 'service_fee_amount', 'total_amount'])

    @staticmethod
    @transaction.atomic
    def send_to_kitchen(order_id: str) -> list:
        """
        Taomlarni oshxonaga yuborish: har bir sex uchun alohida KitchenTicket yaratish.
        """
        order = Order.objects.select_for_update().get(id=order_id)
        new_items = order.items.filter(status=OrderItemStatus.NEW)
        if not new_items.exists():
            return []

        # Sexlar bo'yicha guruhlash
        station_items = {}
        for item in new_items:
            station = item.kitchen_station
            if not station:
                continue
            station_items.setdefault(station, []).append(item)

        created_tickets = []
        ticket_seq = 1
        for station, items in station_items.items():
            ticket_number = f"KT-{order.order_number}-{ticket_seq}"
            ticket_seq += 1

            ticket_items_payload = []
            for it in items:
                ticket_items_payload.append({
                    'name': it.dish_name,
                    'quantity': it.quantity,
                    'course_number': it.course_number,
                    'notes': it.notes,
                    'modifiers': [{'name': m.name} for m in it.modifiers.all()],
                })

            raw_text = EscPosReceiptBuilder.build_kitchen_ticket(
                ticket_number=ticket_number,
                station_name=station.name,
                table_number=order.table.number if order.table else "Olib ketish",
                waiter_name=order.waiter.full_name if order.waiter else "Kassir",
                items=ticket_items_payload,
            )

            ticket = KitchenTicket.objects.create(
                company=order.company,
                branch=order.branch,
                order=order,
                station=station,
                ticket_number=ticket_number,
                payload={'raw_text': raw_text, 'items': ticket_items_payload},
            )
            created_tickets.append(ticket)

        new_items.update(status=OrderItemStatus.SENT)
        order.status = OrderStatus.SENT_TO_KITCHEN
        order.save(update_fields=['status'])
        return created_tickets

    @staticmethod
    @transaction.atomic
    def void_item(order_item_id: str, manager_pin: str, reason: str) -> dict:
        """
        Oshxonaga yuborilgan taomni bekor qilish.
        Xavfsizlik: Faqat Menejer yoki Ega PIN-kodi tasdig'i bilan!
        Oshxonaga "BEKOR" chiptasi chiqariladi va taom isrofga yoziladi.
        """
        item = OrderItem.objects.select_for_update().get(id=order_item_id)
        order = Order.objects.select_for_update().get(id=item.order_id)

        # Menejer yoki Ega PIN kodini tekshirish
        authorized_managers = User.objects.filter(
            company=order.company,
            role__in=[UserRole.MANAGER, UserRole.OWNER],
            is_active=True
        )
        approving_manager = None
        for mgr in authorized_managers:
            if mgr.pin_hash and check_password(manager_pin, mgr.pin_hash):
                approving_manager = mgr
                break

        if not approving_manager:
            raise PermissionDenied("Menejer PIN-kodi noto'g'ri! Bekor qilish rad etildi.")

        item.status = OrderItemStatus.VOIDED
        item.void_reason = reason
        item.voided_by_name = approving_manager.full_name
        item.voided_at = timezone.now()
        item.save(update_fields=['status', 'void_reason', 'voided_by_name', 'voided_at'])

        # Oshxona sexi uchun BEKOR chiptasini chop etish
        if item.kitchen_station:
            ticket_number = f"VOID-{order.order_number}"
            void_text = EscPosReceiptBuilder.build_kitchen_ticket(
                ticket_number=ticket_number,
                station_name=item.kitchen_station.name,
                table_number=order.table.number if order.table else "Olib ketish",
                waiter_name=approving_manager.full_name,
                items=[{'name': item.dish_name, 'quantity': item.quantity, 'notes': f"SABAB: {reason}"}],
                ticket_type="ITEM_VOID",
            )
            KitchenTicket.objects.create(
                company=order.company,
                branch=order.branch,
                order=order,
                station=item.kitchen_station,
                ticket_type=KitchenTicket.TicketType.ITEM_VOID,
                ticket_number=ticket_number,
                payload={'raw_text': void_text, 'reason': reason},
            )

        OrderService._recalculate_totals(order)
        return {
            'order_item_id': str(item.id),
            'dish_name': item.dish_name,
            'approved_by': approving_manager.full_name,
            'reason': reason,
            'new_order_total': float(order.total_amount),
        }

    @staticmethod
    @transaction.atomic
    def pay_order(
        order_id: str,
        shift_id: str,
        cashier,
        payment_method: str,
        tendered_amount: decimal.Decimal,
        tip_amount: decimal.Decimal = decimal.Decimal('0.0'),
    ) -> Receipt:
        """
        Buyurtmaga to'lov qabul qilish, smenaga tushum qo'shish, chek chop etish va stolni bo'shatish.
        """
        order = Order.objects.select_for_update().get(id=order_id)
        shift = Shift.objects.select_for_update().get(id=shift_id, is_closed=False)

        if order.status == OrderStatus.PAID:
            raise ValidationError("Ushbu buyurtma allaqachon to'langan!")

        total_to_pay = order.total_amount
        change_amount = decimal.Decimal('0.0')

        if payment_method == PaymentMethod.CASH:
            if tendered_amount < total_to_pay:
                raise ValidationError(f"Mijoz bergan pul kam ({tendered_amount} < {total_to_pay})")
            change_amount = tendered_amount - total_to_pay

        # 1. To'lov yozuvi
        payment = Payment.objects.create(
            company=order.company,
            branch=order.branch,
            order=order,
            shift=shift,
            method=payment_method,
            amount=total_to_pay,
            tendered_amount=tendered_amount,
            change_amount=change_amount,
            tip_amount=tip_amount,
            cashier=cashier,
        )

        # 2. Smena ko'rsatkichlarini yangilash
        shift.total_sales += total_to_pay
        shift.orders_count += 1
        if payment_method == PaymentMethod.CASH:
            shift.cash_sales += total_to_pay
        elif payment_method in [PaymentMethod.UZCARD, PaymentMethod.HUMO]:
            shift.card_sales += total_to_pay
        elif payment_method in [PaymentMethod.CLICK, PaymentMethod.PAYME, PaymentMethod.UZUM]:
            shift.app_sales += total_to_pay
        elif payment_method == PaymentMethod.DEBT:
            shift.debt_sales += total_to_pay

        shift.save()

        # 3. Buyurtmani yopish va stolni bo'shatish
        order.status = OrderStatus.PAID
        order.paid_amount = total_to_pay
        order.tip_amount = tip_amount
        order.closed_at = timezone.now()
        order.save(update_fields=['status', 'paid_amount', 'tip_amount', 'closed_at'])

        if order.table:
            order.table.status = TableStatus.VACANT
            order.table.current_order_id = None
            order.table.save(update_fields=['status', 'current_order_id'])

        # 4. Mijoz chekini generatsiya qilish
        items_payload = []
        for it in order.items.exclude(status=OrderItemStatus.VOIDED):
            items_payload.append({
                'name': it.dish_name,
                'quantity': it.quantity,
                'unit_price': it.unit_price,
                'total_price': it.total_price,
                'modifiers': [{'name': m.name, 'price': m.price} for m in it.modifiers.all()]
            })

        receipt_text = EscPosReceiptBuilder.build_customer_receipt(
            company_name=order.company.name,
            branch_name=order.branch.name if order.branch else "",
            phone=order.company.phone,
            address=order.branch.address if order.branch else "",
            order_number=order.order_number,
            table_number=order.table.number if order.table else "Olib ketish",
            waiter_name=order.waiter.full_name if order.waiter else "Kassir",
            cashier_name=cashier.full_name,
            items=items_payload,
            subtotal=order.subtotal,
            service_fee_percent=order.service_fee_percent,
            service_fee_amount=order.service_fee_amount,
            discount_amount=order.discount_amount,
            total_amount=order.total_amount,
            payment_method=payment.get_method_display(),
            tendered_amount=tendered_amount,
            change_amount=change_amount,
        )

        receipt = Receipt.objects.create(
            company=order.company,
            branch=order.branch,
            order=order,
            receipt_number=f"REC-{order.order_number}",
            receipt_type=ReceiptType.CUSTOMER,
            total_amount=total_to_pay,
            payload_text=receipt_text,
        )
        return receipt

    @staticmethod
    @transaction.atomic
    def close_shift(shift_id: str, closed_by, actual_cash: decimal.Decimal) -> Shift:
        """
        Smenani yopish, haqiqiy naqd pul bilan solishtirish, kamomad/ortiqchani aniqlash va Z-hisobot yaratish.
        """
        shift = Shift.objects.select_for_update().get(id=shift_id, is_closed=False)
        
        expected_cash = shift.starting_cash + shift.cash_sales + shift.cash_in - shift.cash_out
        diff = actual_cash - expected_cash

        shift.closed_by = closed_by
        shift.closed_at = timezone.now()
        shift.expected_cash = expected_cash
        shift.actual_cash = actual_cash
        shift.cash_difference = diff
        shift.is_closed = True

        z_text = EscPosReceiptBuilder.build_z_report(
            shift_number=shift.shift_number,
            opened_at=shift.opened_at.strftime("%d.%m.%Y %H:%M"),
            closed_at=shift.closed_at.strftime("%d.%m.%Y %H:%M"),
            cashier_name=closed_by.full_name,
            starting_cash=shift.starting_cash,
            total_sales=shift.total_sales,
            cash_sales=shift.cash_sales,
            card_sales=shift.card_sales,
            app_sales=shift.app_sales,
            debt_sales=shift.debt_sales,
            cash_in=shift.cash_in,
            cash_out=shift.cash_out,
            actual_cash=actual_cash,
            difference=diff,
            orders_count=shift.orders_count,
        )

        shift.z_report_data = {'raw_text': z_text, 'expected': float(expected_cash), 'actual': float(actual_cash)}
        shift.save()

        # Z-Hisobot chekini saqlash
        Receipt.objects.create(
            company=shift.company,
            branch=shift.branch,
            receipt_number=f"Z-{shift.shift_number}",
            receipt_type=ReceiptType.Z_REPORT,
            total_amount=shift.total_sales,
            payload_text=z_text,
        )
        return shift

import decimal
from rest_framework import serializers, viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.orders.models import Order, OrderItem, OrderItemModifier, KitchenTicket, OrderStatus
from apps.orders.services import OrderService
from apps.sales.models import Shift

class OrderItemModifierSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItemModifier
        fields = ['id', 'name', 'price']


class OrderItemSerializer(serializers.ModelSerializer):
    modifiers = OrderItemModifierSerializer(many=True, read_only=True)

    class Meta:
        model = OrderItem
        fields = [
            'id', 'dish_name', 'unit_price', 'quantity', 'total_price',
            'course_number', 'seat_number', 'status', 'notes', 'modifiers',
            'void_reason', 'voided_by_name', 'voided_at'
        ]


class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    table_number = serializers.CharField(source='table.number', read_only=True)
    waiter_name = serializers.CharField(source='waiter.full_name', read_only=True)

    class Meta:
        model = Order
        fields = [
            'id', 'order_number', 'order_type', 'status', 'table', 'table_number',
            'waiter', 'waiter_name', 'guests_count', 'subtotal',
            'service_fee_percent', 'service_fee_amount', 'discount_amount',
            'total_amount', 'paid_amount', 'notes', 'opened_at', 'closed_at', 'items'
        ]


class KitchenTicketSerializer(serializers.ModelSerializer):
    station_name = serializers.CharField(source='station.name', read_only=True)

    class Meta:
        model = KitchenTicket
        fields = ['id', 'order', 'station', 'station_name', 'ticket_type', 'ticket_number', 'payload', 'is_printed', 'created_at']


class OrderViewSet(viewsets.ModelViewSet):
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = Order.objects.prefetch_related('items__modifiers').select_related('table', 'waiter')
        status_param = self.request.query_params.get('status')
        if status_param:
            qs = qs.filter(status=status_param)
        return qs

    def perform_create(self, serializer):
        order = OrderService.create_order(
            company=self.request.user.company,
            branch=self.request.user.branch,
            order_type=serializer.validated_data.get('order_type', 'DINE_IN'),
            table_id=self.request.data.get('table_id'),
            waiter=self.request.user,
            guests_count=serializer.validated_data.get('guests_count', 1),
            notes=serializer.validated_data.get('notes', ''),
        )
        serializer.instance = order

    @action(methods=['post'], detail=True, url_path='add-items')
    def add_items(self, request, pk=None):
        items_data = request.data.get('items', [])
        order = OrderService.add_items_to_order(order_id=pk, items_data=items_data)
        return Response(OrderSerializer(order).data)

    @action(methods=['post'], detail=True, url_path='send-kitchen')
    def send_kitchen(self, request, pk=None):
        tickets = OrderService.send_to_kitchen(order_id=pk)
        return Response(KitchenTicketSerializer(tickets, many=True).data)

    @action(methods=['post'], detail=True, url_path='void-item')
    def void_item(self, request, pk=None):
        order_item_id = request.data.get('order_item_id')
        manager_pin = request.data.get('manager_pin')
        reason = request.data.get('reason', 'Mijoz rad etdi')
        result = OrderService.void_item(
            order_item_id=order_item_id,
            manager_pin=manager_pin,
            reason=reason
        )
        return Response(result)

    @action(methods=['post'], detail=True, url_path='pay')
    def pay(self, request, pk=None):
        shift_id = request.data.get('shift_id')
        payment_method = request.data.get('payment_method', 'CASH')
        tendered_amount = decimal.Decimal(str(request.data.get('tendered_amount', '0')))
        tip_amount = decimal.Decimal(str(request.data.get('tip_amount', '0')))

        receipt = OrderService.pay_order(
            order_id=pk,
            shift_id=shift_id,
            cashier=request.user,
            payment_method=payment_method,
            tendered_amount=tendered_amount,
            tip_amount=tip_amount,
        )
        return Response({
            'receipt_number': receipt.receipt_number,
            'receipt_text': receipt.payload_text,
            'total_paid': float(receipt.total_amount),
        })


class KitchenTicketViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = KitchenTicketSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return KitchenTicket.objects.select_related('station', 'order').filter(is_printed=False)

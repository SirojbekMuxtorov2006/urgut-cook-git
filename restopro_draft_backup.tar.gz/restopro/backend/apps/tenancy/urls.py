from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.tenancy.views import BranchViewSet, DeviceViewSet

router = DefaultRouter()
router.register('branches', BranchViewSet, basename='branch')
router.register('devices', DeviceViewSet, basename='device')

urlpatterns = [
    path('', include(router.urls)),
]

import uuid
from django.db import models
from apps.common.utils.uuid import generate_uuidv7

class BusinessType(models.TextChoices):
    NATIONAL_KITCHEN = 'NATIONAL_KITCHEN', 'Milliy oshxona'
    RESTAURANT = 'RESTAURANT', 'Restoran / To\'yxona'
    CAFE = 'CAFE', 'Kafe / Kofeyniya'
    FAST_FOOD = 'FAST_FOOD', 'Fast-food'
    DARK_KITCHEN = 'DARK_KITCHEN', 'Yetkazib berish oshxonasi'


class Company(models.Model):
    id = models.UUIDField(primary_key=True, default=generate_uuidv7, editable=False)
    name = models.CharField(max_length=255, verbose_name="Kompaniya nomi")
    slug = models.SlugField(max_length=255, unique=True)
    business_type = models.CharField(
        max_length=50,
        choices=BusinessType.choices,
        default=BusinessType.NATIONAL_KITCHEN
    )
    phone = models.CharField(max_length=32, unique=True)
    email = models.EmailField(blank=True, null=True)
    currency = models.CharField(max_length=10, default="UZS")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Kompaniya"
        verbose_name_plural = "Kompaniyalar"

    def __str__(self):
        return f"{self.name} ({self.get_business_type_display()})"


class Plan(models.Model):
    id = models.UUIDField(primary_key=True, default=generate_uuidv7, editable=False)
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=50, unique=True)
    price_monthly = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    max_branches = models.PositiveIntegerField(default=1)
    max_pos_devices = models.PositiveIntegerField(default=2)
    max_waiter_devices = models.PositiveIntegerField(default=5)
    max_kds_devices = models.PositiveIntegerField(default=2)
    features = models.JSONField(default=dict)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name} - {self.price_monthly:,.0f} UZS"


class Subscription(models.Model):
    class Status(models.TextChoices):
        TRIAL = 'TRIAL', 'Sinov davri'
        ACTIVE = 'ACTIVE', 'Faol'
        GRACE_PERIOD = 'GRACE_PERIOD', 'Imtiyozli davr'
        EXPIRED = 'EXPIRED', 'Muddati tugagan'

    id = models.UUIDField(primary_key=True, default=generate_uuidv7, editable=False)
    company = models.OneToOneField(Company, on_delete=models.CASCADE, related_name='subscription')
    plan = models.ForeignKey(Plan, on_delete=models.PROTECT)
    status = models.CharField(max_length=30, choices=Status.choices, default=Status.TRIAL)
    starts_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    signed_offline_token = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.company.name} - {self.plan.name} ({self.status})"


class Branch(models.Model):
    id = models.UUIDField(primary_key=True, default=generate_uuidv7, editable=False)
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='branches')
    name = models.CharField(max_length=255)
    phone = models.CharField(max_length=32, blank=True)
    address = models.CharField(max_length=500, blank=True)
    service_fee_percent = models.DecimalField(max_digits=5, decimal_places=2, default=10.0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Filial"
        verbose_name_plural = "Filiallar"

    def __str__(self):
        return f"{self.company.name} - {self.name}"


class DeviceMode(models.TextChoices):
    POS = 'POS', 'Kassa (POS terminal)'
    HUB = 'HUB', 'Asosiy kassa (Lokal Hub)'
    WAITER = 'WAITER', 'Ofitsiant ilovasi'
    KDS = 'KDS', 'Oshxona ekrani (KDS)'
    MANAGER = 'MANAGER', 'Boshqaruv (Menejer)'
    COURIER = 'COURIER', 'Kuryer rejimi'


class Device(models.Model):
    id = models.UUIDField(primary_key=True, default=generate_uuidv7, editable=False)
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='devices')
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, related_name='devices')
    name = models.CharField(max_length=150)
    device_code = models.CharField(max_length=64, unique=True)
    mode = models.CharField(max_length=30, choices=DeviceMode.choices, default=DeviceMode.POS)
    token = models.CharField(max_length=255, unique=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    is_hub = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    last_seen_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Qurilma"
        verbose_name_plural = "Qurilmalar"

    def __str__(self):
        return f"{self.name} [{self.mode}] ({self.branch.name})"


class Setting(models.Model):
    id = models.UUIDField(primary_key=True, default=generate_uuidv7, editable=False)
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='settings')
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, null=True, blank=True, related_name='settings')
    key = models.CharField(max_length=100)
    value = models.JSONField(default=dict)

    class Meta:
        unique_together = ('company', 'branch', 'key')

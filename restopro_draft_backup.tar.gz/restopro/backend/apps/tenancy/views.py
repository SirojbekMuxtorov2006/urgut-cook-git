from rest_framework import serializers, viewsets, permissions
from apps.tenancy.models import Branch, Device, Company, Subscription

class BranchSerializer(serializers.ModelSerializer):
    class Meta:
        model = Branch
        fields = ['id', 'name', 'phone', 'address', 'service_fee_percent', 'is_active', 'created_at']
        read_only_fields = ['id', 'created_at']


class DeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = ['id', 'name', 'device_code', 'mode', 'is_hub', 'is_active', 'last_seen_at', 'ip_address']
        read_only_fields = ['id', 'last_seen_at']


class BranchViewSet(viewsets.ModelViewSet):
    serializer_class = BranchSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Branch.objects.filter(company=self.request.user.company, is_active=True)

    def perform_create(self, serializer):
        serializer.save(company=self.request.user.company)


class DeviceViewSet(viewsets.ModelViewSet):
    serializer_class = DeviceSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Device.objects.filter(company=self.request.user.company)

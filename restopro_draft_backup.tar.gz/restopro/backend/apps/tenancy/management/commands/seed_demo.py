import decimal
from django.core.management.base import BaseCommand
from django.contrib.auth.hashers import make_password
from django.utils import timezone
from datetime import timedelta

from apps.tenancy.models import Company, Branch, Plan, Subscription, Device, DeviceMode, BusinessType
from apps.accounts.models import User, UserRole
from apps.floor.models import Hall, Table, TableStatus
from apps.menu.models import Category, MenuItem, MenuItemVariant, ModifierGroup, Modifier, KitchenStation, UnitType
from apps.inventory.models import Ingredient, TechCard, TechCardItem

class Command(BaseCommand):
    help = "RestoPro SaaS uchun 1-bosqich boshlang'ich demo ma'lumotlarini yuklash (Seed)"

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING("🌱 RestoPro: Baza demo ma'lumotlari yuklanmoqda..."))

        # 1. Tarif rejasini yaratish
        plan, _ = Plan.objects.get_or_create(
            code='enterprise_pro',
            defaults={
                'name': 'RestoPro Enterprise',
                'price_monthly': decimal.Decimal('490000.00'),
                'max_branches': 3,
                'max_pos_devices': 5,
                'max_waiter_devices': 15,
                'max_kds_devices': 5,
                'features': {'kds': True, 'recipes': True, 'qr_menu': True, 'delivery': True, 'hub': True}
            }
        )

        # 2. Kompaniya
        company, _ = Company.objects.update_or_create(
            slug='chorsu-milliy',
            defaults={
                'name': 'Chorsu Milliy Taomlar Markazi',
                'business_type': BusinessType.NATIONAL_KITCHEN,
                'phone': '+998901112233',
                'email': 'info@chorsu.uz',
                'currency': 'UZS',
                'is_active': True,
            }
        )

        # 3. Filial
        branch, _ = Branch.objects.update_or_create(
            company=company,
            name='Bosh Filial (Chorsu)',
            defaults={
                'phone': '+998901112233',
                'address': 'Toshkent sh., Navoiy ko\'chasi 42-uy',
                'service_fee_percent': decimal.Decimal('10.00'),
                'is_active': True,
            }
        )

        # Obuna
        Subscription.objects.update_or_create(
            company=company,
            defaults={
                'plan': plan,
                'status': Subscription.Status.ACTIVE,
                'expires_at': timezone.now() + timedelta(days=90),
                'signed_offline_token': 'RESTOPRO_OFFLINE_LICENSE_VERIFIED_2026'
            }
        )

        # 4. Foydalanuvchilar (1 Ega, 1 Menejer, 2 Kassir, 4 Ofitsiant, 2 Oshpaz)
        users_data = [
            # Ega
            ('+998901112233', 'Akrom Rahimov (Ega)', UserRole.OWNER, '1111', True),
            # Menejer
            ('+998902223344', 'Sardor Qodirov (Menejer)', UserRole.MANAGER, '2222', True),
            # Kassirlar
            ('+998903334455', 'Dilshod Aliyev (Kassir 1)', UserRole.CASHIER, '1234', False),
            ('+998903334466', 'Nodira Karimova (Kassir 2)', UserRole.CASHIER, '5678', False),
            # Ofitsiantlar
            ('+998904445561', 'Aziz Bekzodov (Ofitsiant 1)', UserRole.WAITER, '1001', False),
            ('+998904445562', 'Bobur Mirzayev (Ofitsiant 2)', UserRole.WAITER, '1002', False),
            ('+998904445563', 'Jasur Rustamov (Ofitsiant 3)', UserRole.WAITER, '1003', False),
            ('+998904445564', 'Malika Saidova (Ofitsiant 4)', UserRole.WAITER, '1004', False),
            # Oshpazlar
            ('+998905556671', 'Usta Mahmud (Bosh Oshpaz)', UserRole.CHEF, '2001', False),
            ('+998905556672', 'Usta Faxriddin (Somsa Ustasi)', UserRole.CHEF, '2002', False),
        ]

        for phone, name, role, pin, is_staff in users_data:
            user, created = User.objects.update_or_create(
                phone=phone,
                defaults={
                    'full_name': name,
                    'company': company,
                    'branch': branch,
                    'role': role,
                    'pin_hash': make_password(pin),
                    'is_staff': is_staff,
                    'is_active': True,
                }
            )
            if created:
                user.set_password('restopro123')
                user.save()

        # 5. Sexlar (3 ta)
        st_hot, _ = KitchenStation.objects.update_or_create(
            company=company, branch=branch, name='Issiq sex',
            defaults={'printer_ip': '192.168.1.101', 'is_active': True}
        )
        st_somsa, _ = KitchenStation.objects.update_or_create(
            company=company, branch=branch, name='Somsa tandiri',
            defaults={'printer_ip': '192.168.1.102', 'is_active': True}
        )
        st_bar, _ = KitchenStation.objects.update_or_create(
            company=company, branch=branch, name='Bar va Salatlar',
            defaults={'printer_ip': '192.168.1.103', 'is_active': True}
        )

        # 6. Qurilmalar (POS Hub, Waiter tablet, KDS screen)
        Device.objects.update_or_create(
            device_code='POS-MAIN-01',
            defaults={
                'company': company, 'branch': branch, 'name': 'Asosiy Kassa (Hub)',
                'mode': DeviceMode.HUB, 'is_hub': True, 'token': 'hub_token_main_pos_01',
                'is_active': True
            }
        )
        Device.objects.update_or_create(
            device_code='KDS-KITCHEN-01',
            defaults={
                'company': company, 'branch': branch, 'name': 'Oshxona KDS Ekrani',
                'mode': DeviceMode.KDS, 'is_hub': False, 'token': 'kds_token_kitchen_01',
                'is_active': True
            }
        )

        # 7. Zallar va 20 ta stol
        hall_main, _ = Hall.objects.update_or_create(
            company=company, branch=branch, name='Asosiy zal',
            defaults={'sort_order': 1, 'is_active': True}
        )
        hall_terrace, _ = Hall.objects.update_or_create(
            company=company, branch=branch, name='Yozgi ayvon',
            defaults={'sort_order': 2, 'is_active': True}
        )

        for i in range(1, 13):
            Table.objects.update_or_create(
                company=company, branch=branch, hall=hall_main, number=f"{i}",
                defaults={
                    'seats': 4 if i <= 8 else 6,
                    'status': TableStatus.VACANT,
                    'pos_x': float((i - 1) % 4 * 120 + 20),
                    'pos_y': float((i - 1) // 4 * 120 + 20),
                    'is_active': True
                }
            )

        for i in range(13, 21):
            Table.objects.update_or_create(
                company=company, branch=branch, hall=hall_terrace, number=f"{i}",
                defaults={
                    'seats': 6 if i <= 16 else 8,
                    'status': TableStatus.VACANT,
                    'pos_x': float((i - 13) % 4 * 140 + 20),
                    'pos_y': float((i - 13) // 4 * 140 + 20),
                    'is_active': True
                }
            )

        # 8. Xomashyolar (Ombor uchun asosiy ingredientlar)
        ingredients_map = {}
        raw_items = [
            ("Guruch (Lazer)", "kg", "350.0", "50.0", "28000"),
            ("Mol go'shti (lahm)", "kg", "180.0", "30.0", "95000"),
            ("Qo'y go'shti", "kg", "120.0", "20.0", "105000"),
            ("Qo'y dumbasi", "kg", "60.0", "10.0", "80000"),
            ("Sariq sabzi", "kg", "250.0", "40.0", "4000"),
            ("Piyoz", "kg", "200.0", "30.0", "3500"),
            ("Paxta/O'simlik yog'i", "litr", "150.0", "25.0", "18000"),
            ("Oliy nav un", "kg", "300.0", "50.0", "8000"),
            ("Qazi", "kg", "40.0", "5.0", "140000"),
            ("Kartoshka", "kg", "180.0", "30.0", "5000"),
            ("Pomidor", "kg", "100.0", "20.0", "15000"),
            ("Bodring", "kg", "80.0", "15.0", "12000"),
            ("Ko'katlar", "kg", "30.0", "5.0", "20000"),
            ("Choy (Ko'k 95)", "kg", "25.0", "5.0", "65000"),
            ("Shakar", "kg", "60.0", "10.0", "13000"),
        ]

        for name, unit, stock, min_s, cost in raw_items:
            ing, _ = Ingredient.objects.update_or_create(
                company=company, branch=branch, name=name,
                defaults={
                    'unit': unit,
                    'current_stock': decimal.Decimal(stock),
                    'min_stock': decimal.Decimal(min_s),
                    'cost_price': decimal.Decimal(cost),
                    'is_active': True
                }
            )
            ingredients_map[name] = ing

        # 9. Menyu kategoriyalari
        cat_first, _ = Category.objects.update_or_create(
            company=company, branch=branch, name_uz='Birinchi taomlar',
            defaults={'name_ru': 'Первые блюда', 'icon': 'soup', 'color': '#f97316', 'sort_order': 1}
        )
        cat_second, _ = Category.objects.update_or_create(
            company=company, branch=branch, name_uz='Ikkinchi taomlar',
            defaults={'name_ru': 'Вторые блюда', 'icon': 'utensils', 'color': '#eab308', 'sort_order': 2}
        )
        cat_kebab, _ = Category.objects.update_or_create(
            company=company, branch=branch, name_uz='Kavob va Gril',
            defaults={'name_ru': 'Шашлыки', 'icon': 'flame', 'color': '#ef4444', 'sort_order': 3}
        )
        cat_somsa, _ = Category.objects.update_or_create(
            company=company, branch=branch, name_uz='Somsa va Non',
            defaults={'name_ru': 'Самса и лепешки', 'icon': 'cookie', 'color': '#d97706', 'sort_order': 4}
        )
        cat_salad, _ = Category.objects.update_or_create(
            company=company, branch=branch, name_uz='Salatlar va Gazaklar',
            defaults={'name_ru': 'Салаты', 'icon': 'salad', 'color': '#22c55e', 'sort_order': 5}
        )
        cat_drinks, _ = Category.objects.update_or_create(
            company=company, branch=branch, name_uz='Choy va Ichimliklar',
            defaults={'name_ru': 'Напитки', 'icon': 'cup-soda', 'color': '#06b6d4', 'sort_order': 6}
        )

        # 10. 40 ta Taom va Ichimliklar
        dishes = [
            # Birinchi taomlar (6)
            (cat_first, st_hot, "Sho'rva (Qo'y go'shtli)", "Шурпа", "42000", "22000", UnitType.PORTION, 10),
            (cat_first, st_hot, "Ko'za sho'rva", "Кюза шурпа в горшочке", "48000", "25000", UnitType.PORTION, 15),
            (cat_first, st_hot, "Chuchvara sho'rva", "Пельмени с бульоном", "38000", "18000", UnitType.PORTION, 12),
            (cat_first, st_hot, "Mastava", "Мастава", "36000", "17000", UnitType.PORTION, 10),
            (cat_first, st_hot, "No'xat sho'rva", "Гороховый суп", "40000", "19000", UnitType.PORTION, 12),
            (cat_first, st_hot, "Lag'mon (Suyuq)", "Лагман суп", "44000", "21000", UnitType.PORTION, 15),

            # Ikkinchi taomlar (12)
            (cat_second, st_hot, "To'y Oshi (Toshkentcha)", "Свадебный плов", "38000", "18500", UnitType.PORTION, 5),
            (cat_second, st_hot, "Choyxona Palov", "Чайханский плов", "42000", "20000", UnitType.PORTION, 5),
            (cat_second, st_hot, "Samarqandcha Osh", "Самаркандский плов", "40000", "19000", UnitType.PORTION, 5),
            (cat_second, st_hot, "Qovurma Lag'mon", "Жареный лагман", "46000", "23000", UnitType.PORTION, 15),
            (cat_second, st_hot, "Manti (Go'shtli)", "Манты с мясом (4 dona)", "42000", "20000", UnitType.PORTION, 20),
            (cat_second, st_hot, "Qozon Kabob (Mol)", "Казан-кебаб из говядины", "65000", "34000", UnitType.PORTION, 25),
            (cat_second, st_hot, "Qozon Kabob (Qo'y)", "Казан-кебаб из баранины", "75000", "39000", UnitType.PORTION, 25),
            (cat_second, st_hot, "Norin (Go'shti bilan)", "Нарын с бульоном", "45000", "22000", UnitType.PORTION, 10),
            (cat_second, st_hot, "Dimlama", "Дымляма", "48000", "24000", UnitType.PORTION, 20),
            (cat_second, st_hot, "Jiz (Jizzaxcha)", "Жиз по-джизакски", "72000", "38000", UnitType.PORTION, 20),
            (cat_second, st_hot, "Beshbarmoq", "Бешбармак", "68000", "35000", UnitType.PORTION, 25),
            (cat_second, st_hot, "Dolma", "Долма", "45000", "22000", UnitType.PORTION, 15),

            # Kaboblar (8)
            (cat_kebab, st_hot, "Qiyma Shashlik", "Люля-кебаб", "22000", "10500", UnitType.PIECE, 12),
            (cat_kebab, st_hot, "Kuskovoy Shashlik (Mol)", "Шашлык кусковой из говядины", "26000", "13000", UnitType.PIECE, 12),
            (cat_kebab, st_hot, "Qo'y Go'shti Shashlik", "Шашлык из баранины", "28000", "14000", UnitType.PIECE, 12),
            (cat_kebab, st_hot, "Jigar Shashlik", "Шашлык из печени с думбой", "20000", "9500", UnitType.PIECE, 10),
            (cat_kebab, st_hot, "Tovuq Shashlik", "Шашлык куриный", "20000", "9000", UnitType.PIECE, 12),
            (cat_kebab, st_hot, "Napoleon Shashlik", "Шашлык Наполеон", "32000", "16000", UnitType.PIECE, 15),
            (cat_kebab, st_hot, "Qovurg'a Shashlik (Qo'y)", "Шашлык из бараньих ребрышек", "32000", "16000", UnitType.PIECE, 15),
            (cat_kebab, st_hot, "Pomidor/Sabzavot Shashlik", "Овощной шашлык", "15000", "5000", UnitType.PIECE, 10),

            # Somsa va Non (5)
            (cat_somsa, st_somsa, "Tandir Somsa (Go'shtli)", "Тандырная самса с мясом", "14000", "6500", UnitType.PIECE, 5),
            (cat_somsa, st_somsa, "Varaqi Somsa", "Слоёная самса", "12000", "5500", UnitType.PIECE, 5),
            (cat_somsa, st_somsa, "Qovoqli Somsa", "Самса с тыквой", "9000", "3500", UnitType.PIECE, 5),
            (cat_somsa, st_somsa, "Toshkent Non", "Лепёшка ташкентская", "5000", "1800", UnitType.PIECE, 1),
            (cat_somsa, st_somsa, "Patir Non (Moyli)", "Патыр масляный", "12000", "4500", UnitType.PIECE, 1),

            # Salatlar (5)
            (cat_salad, st_bar, "Achchiq-chuchuk", "Ачик-чучук", "15000", "4500", UnitType.PORTION, 5),
            (cat_salad, st_bar, "Bahor Salati", "Весенний салат", "18000", "6000", UnitType.PORTION, 5),
            (cat_salad, st_bar, "Suzma (Ko'katli)", "Сузьма с зеленью", "14000", "4000", UnitType.PORTION, 3),
            (cat_salad, st_bar, "Fransuzcha Salat", "Французский салат", "25000", "11000", UnitType.PORTION, 7),
            (cat_salad, st_bar, "Zaytun va Tuzlamalar", "Ассорти солений", "24000", "9000", UnitType.PORTION, 3),

            # Ichimliklar (4)
            (cat_drinks, st_bar, "Ko'k Choy (Choynak)", "Чай зелёный (чайник)", "6000", "800", UnitType.PIECE, 2),
            (cat_drinks, st_bar, "Qora Choy (Limonli)", "Чай чёрный с лимоном", "10000", "1500", UnitType.PIECE, 2),
            (cat_drinks, st_bar, "Uy Kompoti (Mevadan)", "Домашний компот (1л)", "18000", "4500", UnitType.LITER, 2),
            (cat_drinks, st_bar, "Gazsiz Suv (0.5l)", "Вода без газа 0.5л", "5000", "2200", UnitType.PIECE, 1),
        ]

        created_items = []
        for cat, station, name_uz, name_ru, price, cost, unit, cook_time in dishes:
            item, _ = MenuItem.objects.update_or_create(
                company=company, branch=branch, name_uz=name_uz,
                defaults={
                    'category': cat,
                    'kitchen_station': station,
                    'name_ru': name_ru,
                    'price': decimal.Decimal(price),
                    'cost_price': decimal.Decimal(cost),
                    'unit': unit,
                    'cooking_time_minutes': cook_time,
                    'is_available': True,
                    'is_popular': True if "Osh" in name_uz or "Shashlik" in name_uz else False,
                }
            )
            created_items.append(item)

        # 11. Variantlar (Osh uchun: 0.5 pors, 1 pors, 1 kg lagan)
        osh_item = MenuItem.objects.filter(company=company, name_uz__contains="To'y Oshi").first()
        if osh_item:
            MenuItemVariant.objects.update_or_create(
                company=company, branch=branch, menu_item=osh_item, name="0.5 porsiya",
                defaults={'price': decimal.Decimal('22000.00'), 'is_default': False}
            )
            MenuItemVariant.objects.update_or_create(
                company=company, branch=branch, menu_item=osh_item, name="1 porsiya",
                defaults={'price': decimal.Decimal('38000.00'), 'is_default': True}
            )
            MenuItemVariant.objects.update_or_create(
                company=company, branch=branch, menu_item=osh_item, name="1 kg lagan (4 kishilik)",
                defaults={'price': decimal.Decimal('150000.00'), 'is_default': False}
            )

            # Osh uchun modifikatorlar
            mod_group, _ = ModifierGroup.objects.update_or_create(
                company=company, branch=branch, name="Osh qo'shimchalari",
                defaults={'is_required': False, 'min_select': 0, 'max_select': 3}
            )
            Modifier.objects.update_or_create(
                company=company, branch=branch, group=mod_group, name="+ Qazi (1 tilim)",
                defaults={'price': decimal.Decimal('10000.00')}
            )
            Modifier.objects.update_or_create(
                company=company, branch=branch, group=mod_group, name="+ Bedana tuxum (2 dona)",
                defaults={'price': decimal.Decimal('5000.00')}
            )
            Modifier.objects.update_or_create(
                company=company, branch=branch, group=mod_group, name="+ Achchiq murch",
                defaults={'price': decimal.Decimal('0.00')}
            )

            # 12. Texnologik karta (Retsept kalkulyatsiyasi)
            card, _ = TechCard.objects.update_or_create(
                company=company, branch=branch, menu_item=osh_item,
                defaults={'yield_amount': decimal.Decimal('1.00'), 'description': '1 porsiya standart to\'y oshi'}
            )
            recipe_ingredients = [
                ("Guruch (Lazer)", "0.150", "0.150"),
                ("Mol go'shti (lahm)", "0.120", "0.100"),
                ("Qo'y dumbasi", "0.030", "0.030"),
                ("Sariq sabzi", "0.150", "0.120"),
                ("Piyoz", "0.050", "0.040"),
                ("Paxta/O'simlik yog'i", "0.040", "0.040"),
            ]
            for ing_name, gross, net in recipe_ingredients:
                ing_obj = ingredients_map.get(ing_name)
                if ing_obj:
                    TechCardItem.objects.update_or_create(
                        company=company, branch=branch, tech_card=card, ingredient=ing_obj,
                        defaults={
                            'gross_weight': decimal.Decimal(gross),
                            'net_weight': decimal.Decimal(net),
                            'waste_percent': decimal.Decimal('10.00')
                        }
                    )

        self.stdout.write(self.style.SUCCESS("✅ RestoPro 1-bosqich demo ma'lumotlari muvaffaqiyatli yuklandi!"))
        self.stdout.write(self.style.SUCCESS(f"   • Kompaniya: {company.name} ({branch.name})"))
        self.stdout.write(self.style.SUCCESS(f"   • Foydalanuvchilar: 1 Ega, 1 Menejer, 2 Kassir, 4 Ofitsiant, 2 Oshpaz"))
        self.stdout.write(self.style.SUCCESS(f"   • Sexlar: 3 ta (Issiq sex, Somsa tandiri, Bar)"))
        self.stdout.write(self.style.SUCCESS(f"   • Zallar: 2 ta ({hall_main.name}, {hall_terrace.name}), 20 ta stol"))
        self.stdout.write(self.style.SUCCESS(f"   • Taomlar: {len(created_items)} ta to'liq milliy taom, variantlar va retsepti bilan"))

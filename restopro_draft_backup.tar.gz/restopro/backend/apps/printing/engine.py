from datetime import datetime
import decimal

class EscPosReceiptBuilder:
    """
    O'zbekiston standartlariga mos ESC/POS mijoz cheklari,
    oshxona chiptalari va X/Z hisobotlarini 58mm/80mm formatda generatsiya qilish.
    """
    @staticmethod
    def build_customer_receipt(
        company_name: str,
        branch_name: str,
        phone: str,
        address: str,
        order_number: str,
        table_number: str,
        waiter_name: str,
        cashier_name: str,
        items: list,
        subtotal: decimal.Decimal,
        service_fee_percent: decimal.Decimal,
        service_fee_amount: decimal.Decimal,
        discount_amount: decimal.Decimal,
        total_amount: decimal.Decimal,
        payment_method: str,
        tendered_amount: decimal.Decimal,
        change_amount: decimal.Decimal,
        paper_width: int = 80,
    ) -> str:
        width = 48 if paper_width == 80 else 32
        sep = "-" * width
        double_sep = "=" * width
        now_str = datetime.now().strftime("%d.%m.%Y  %H:%M")

        lines = [
            company_name.center(width),
            branch_name.center(width),
            address.center(width) if address else "",
            f"Tel: {phone}".center(width),
            sep,
            f"Chek №: {order_number}".ljust(width),
            f"Sana: {now_str}".ljust(width),
            f"Kassir: {cashier_name}   Ofitsiant: {waiter_name}".ljust(width),
            f"Stol: {table_number}".ljust(width),
            sep,
        ]

        # Taomlar jadvali
        for item in items:
            name = item['name']
            qty = item['quantity']
            price = f"{item['unit_price']:,.0f}"
            summa = f"{item['total_price']:,.0f}"
            
            # 1-qator: Taom nomi
            lines.append(name[:width])
            # 2-qator: 2 x 35 000                   70 000
            qty_part = f"  {qty} x {price}"
            lines.append(qty_part + summa.rjust(width - len(qty_part)))

            # Modifikatorlar
            for mod in item.get('modifiers', []):
                lines.append(f"   +{mod['name']} ({mod['price']:,.0f})")

        lines.extend([
            sep,
            f"Jami:{f'{subtotal:,.0f}'.rjust(width - 5)}",
        ])

        if service_fee_amount > 0:
            lines.append(f"Xizmat haqi ({service_fee_percent:,.0f}%):{f'{service_fee_amount:,.0f}'.rjust(width - 19)}")

        if discount_amount > 0:
            lines.append(f"Chegirma:{f'-{discount_amount:,.0f}'.rjust(width - 9)}")

        lines.extend([
            double_sep,
            f"TO'LOVGA:{f'{total_amount:,.0f} so\'m'.rjust(width - 9)}",
            double_sep,
            f"To'lov turi: {payment_method}".ljust(width),
            f"Qabul qilindi:{f'{tendered_amount:,.0f}'.rjust(width - 14)}",
            f"Qaytim:{f'{change_amount:,.0f}'.rjust(width - 7)}",
            sep,
            "Xaridingiz uchun rahmat!".center(width),
            "Fikr bildirish: https://t.me/restopro_bot".center(width),
            "\n\n\n", # Paper cut padding
        ])

        return "\n".join(line for line in lines if line is not None)

    @staticmethod
    def build_kitchen_ticket(
        ticket_number: str,
        station_name: str,
        table_number: str,
        waiter_name: str,
        items: list,
        ticket_type: str = "NEW_ORDER",
        paper_width: int = 80,
    ) -> str:
        width = 48 if paper_width == 80 else 32
        sep = "=" * width
        now_str = datetime.now().strftime("%H:%M:%S")

        title = f"*** {station_name.upper()} CHIPTASI ***"
        if ticket_type == "ITEM_VOID":
            title = "!!! BEKOR QILINDI (ISROF) !!!"

        lines = [
            title.center(width),
            sep,
            f"Chipta №: {ticket_number}      Vaqt: {now_str}",
            f"STOL: {table_number}           Ofitsiant: {waiter_name}",
            sep,
        ]

        for item in items:
            name = item['name']
            qty = f"{item['quantity']} dona"
            course = f"[Kurs {item.get('course_number', 1)}]"
            lines.append(f"{qty.ljust(10)} {name.ljust(width - 20)} {course}")
            if item.get('notes'):
                lines.append(f"  >>> IZOH: {item['notes']}")
            for mod in item.get('modifiers', []):
                lines.append(f"  +{mod['name']}")

        lines.extend([
            sep,
            "\n\n\n",
        ])
        return "\n".join(lines)

    @staticmethod
    def build_z_report(
        shift_number: str,
        opened_at: str,
        closed_at: str,
        cashier_name: str,
        starting_cash: decimal.Decimal,
        total_sales: decimal.Decimal,
        cash_sales: decimal.Decimal,
        card_sales: decimal.Decimal,
        app_sales: decimal.Decimal,
        debt_sales: decimal.Decimal,
        cash_in: decimal.Decimal,
        cash_out: decimal.Decimal,
        actual_cash: decimal.Decimal,
        difference: decimal.Decimal,
        orders_count: int,
        paper_width: int = 80,
    ) -> str:
        width = 48 if paper_width == 80 else 32
        sep = "=" * width
        lines = [
            "*** Z-HISOBOT (SMENA YOPILISHI) ***".center(width),
            sep,
            f"Smena №: {shift_number}".ljust(width),
            f"Kassir: {cashier_name}".ljust(width),
            f"Ochildi: {opened_at}".ljust(width),
            f"Yopildi: {closed_at}".ljust(width),
            f"Jami cheklar soni: {orders_count}".ljust(width),
            "-" * width,
            f"Boshlang'ich naqd:{f'{starting_cash:,.0f}'.rjust(width - 18)}",
            f"Naqd tushum:{f'{cash_sales:,.0f}'.rjust(width - 12)}",
            f"Karta (Uzcard/Humo):{f'{card_sales:,.0f}'.rjust(width - 20)}",
            f"Ilova (Click/Payme):{f'{app_sales:,.0f}'.rjust(width - 20)}",
            f"Nasiya (Qarz):{f'{debt_sales:,.0f}'.rjust(width - 14)}",
            "-" * width,
            f"UMUMIY TUSHUM:{f'{total_sales:,.0f} so\'m'.rjust(width - 14)}",
            "-" * width,
            f"Kassaga kiritildi (+):{f'{cash_in:,.0f}'.rjust(width - 22)}",
            f"Inkassatsiya/Chiqim (-):{f'{cash_out:,.0f}'.rjust(width - 24)}",
            f"Sanalgan naqd pul:{f'{actual_cash:,.0f}'.rjust(width - 18)}",
            f"Kassa farqi:{f'{difference:,.0f}'.rjust(width - 12)}",
            sep,
            "Smena muvaffaqiyatli yopildi".center(width),
            "\n\n\n",
        ]
        return "\n".join(lines)

import decimal
from django.db import models
from django.conf import settings
from apps.common.models import TenantBaseModel
from apps.orders.models import Order

class Shift(TenantBaseModel):
    shift_number = models.CharField(max_length=64, verbose_name="Smena raqami")
    opened_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='opened_shifts'
    )
    closed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='closed_shifts'
    )
    opened_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    
    starting_cash = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="Boshlang'ich naqd pul")
    total_sales = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    cash_sales = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    card_sales = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    app_sales = models.DecimalField(max_digits=14, decimal_places=2, default=0) # Click, Payme, Uzum
    debt_sales = models.DecimalField(max_digits=14, decimal_places=2, default=0) # Nasiya
    
    cash_in = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    cash_out = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    
    expected_cash = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    actual_cash = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="Sanalgan haqiqiy naqd pul")
    cash_difference = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="Kassa farqi (kamomad/ortiqcha)")
    
    orders_count = models.PositiveIntegerField(default=0)
    is_closed = models.BooleanField(default=False)
    z_report_data = models.JSONField(default=dict)

    class Meta:
        verbose_name = "Smena"
        verbose_name_plural = "Smenalar"
        ordering = ['-opened_at']

    def __str__(self):
        return f"Smena #{self.shift_number} ({self.opened_by.full_name}) - {'Yopiq' if self.is_closed else 'Ochiq'}"


class CashOperationType(models.TextChoices):
    CASH_IN = 'CASH_IN', 'Kassaga pul kiritish'
    CASH_OUT = 'CASH_OUT', 'Inkassatsiya / Xarajat'


class CashOperation(TenantBaseModel):
    shift = models.ForeignKey(Shift, on_delete=models.CASCADE, related_name='cash_operations')
    operation_type = models.CharField(max_length=30, choices=CashOperationType.choices)
    amount = models.DecimalField(max_digits=14, decimal_places=2)
    reason = models.CharField(max_length=255)
    performed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)

    def __str__(self):
        return f"{self.get_operation_type_display()}: {self.amount:,.0f} so'm ({self.reason})"


class PaymentMethod(models.TextChoices):
    CASH = 'CASH', 'Naqd pul'
    UZCARD = 'UZCARD', 'Uzcard'
    HUMO = 'HUMO', 'Humo'
    CLICK = 'CLICK', 'Click'
    PAYME = 'PAYME', 'Payme'
    UZUM = 'UZUM', 'Uzum'
    DEBT = 'DEBT', 'Nasiya (Qarz)'
    DEPOSIT = 'DEPOSIT', 'Depozit hisob'


class Payment(TenantBaseModel):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='payments')
    shift = models.ForeignKey(Shift, on_delete=models.CASCADE, related_name='payments')
    method = models.CharField(max_length=30, choices=PaymentMethod.choices, default=PaymentMethod.CASH)
    amount = models.DecimalField(max_digits=14, decimal_places=2)
    tendered_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="Mijoz bergan pul")
    change_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0, verbose_name="Qaytim")
    tip_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    
    cashier = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    transaction_ref = models.CharField(max_length=150, blank=True, null=True)
    is_refunded = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.get_method_display()}: {self.amount:,.0f} so'm (Buyurtma #{self.order.order_number})"


class ReceiptType(models.TextChoices):
    CUSTOMER = 'CUSTOMER', 'Mijoz cheki'
    PRECHECK = 'PRECHECK', 'Pre-chek (Hisob)'
    FISCAL = 'FISCAL', 'Fiskal chek'
    X_REPORT = 'X_REPORT', 'X-Hisobot'
    Z_REPORT = 'Z_REPORT', 'Z-Hisobot'


class Receipt(TenantBaseModel):
    receipt_number = models.CharField(max_length=64, unique=True)
    order = models.ForeignKey(Order, on_delete=models.SET_NULL, null=True, blank=True, related_name='receipts')
    receipt_type = models.CharField(max_length=30, choices=ReceiptType.choices, default=ReceiptType.CUSTOMER)
    total_amount = models.DecimalField(max_digits=14, decimal_places=2)
    payload_text = models.TextField(verbose_name="ESC/POS formatlangan matn")
    qr_code_data = models.CharField(max_length=500, blank=True, null=True)
    is_printed = models.BooleanField(default=True)
    reprinted_count = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"Chek #{self.receipt_number} ({self.get_receipt_type_display()})"

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.sales.views import ShiftViewSet, ReceiptViewSet

router = DefaultRouter()
router.register('shifts', ShiftViewSet, basename='shift')
router.register('receipts', ReceiptViewSet, basename='receipt')

urlpatterns = [
    path('', include(router.urls)),
]

import decimal
from rest_framework import serializers, viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.sales.models import Shift, Payment, Receipt, CashOperation, ReceiptType
from apps.orders.services import OrderService
from apps.printing.engine import EscPosReceiptBuilder

class CashOperationSerializer(serializers.ModelSerializer):
    class Meta:
        model = CashOperation
        fields = ['id', 'operation_type', 'amount', 'reason', 'performed_by', 'created_at']
        read_only_fields = ['id', 'created_at', 'performed_by']


class ShiftSerializer(serializers.ModelSerializer):
    opened_by_name = serializers.CharField(source='opened_by.full_name', read_only=True)
    closed_by_name = serializers.CharField(source='closed_by.full_name', read_only=True)

    class Meta:
        model = Shift
        fields = [
            'id', 'shift_number', 'opened_by', 'opened_by_name', 'closed_by', 'closed_by_name',
            'opened_at', 'closed_at', 'starting_cash', 'total_sales', 'cash_sales',
            'card_sales', 'app_sales', 'debt_sales', 'cash_in', 'cash_out',
            'expected_cash', 'actual_cash', 'cash_difference', 'orders_count', 'is_closed'
        ]


class ReceiptSerializer(serializers.ModelSerializer):
    class Meta:
        model = Receipt
        fields = ['id', 'receipt_number', 'receipt_type', 'total_amount', 'payload_text', 'is_printed', 'created_at']


class ShiftViewSet(viewsets.ModelViewSet):
    serializer_class = ShiftSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Shift.objects.all()

    @action(methods=['post'], detail=False, url_path='open')
    def open_shift(self, request):
        starting_cash = decimal.Decimal(str(request.data.get('starting_cash', '0.0')))
        
        # Ochiq smena borligini tekshirish
        active = Shift.objects.filter(company=request.user.company, is_closed=False).first()
        if active:
            return Response(ShiftSerializer(active).data)

        shift_number = f"S-{request.user.company.id.hex[:4].upper()}-{Shift.objects.filter(company=request.user.company).count() + 1:04d}"
        shift = Shift.objects.create(
            company=request.user.company,
            branch=request.user.branch,
            shift_number=shift_number,
            opened_by=request.user,
            starting_cash=starting_cash,
        )
        return Response(ShiftSerializer(shift).data, status=status.HTTP_201_CREATED)

    @action(methods=['post'], detail=True, url_path='close')
    def close_shift(self, request, pk=None):
        actual_cash = decimal.Decimal(str(request.data.get('actual_cash', '0.0')))
        shift = OrderService.close_shift(shift_id=pk, closed_by=request.user, actual_cash=actual_cash)
        return Response(ShiftSerializer(shift).data)

    @action(methods=['get'], detail=True, url_path='x-report')
    def x_report(self, request, pk=None):
        shift = self.get_object()
        expected = shift.starting_cash + shift.cash_sales + shift.cash_in - shift.cash_out
        x_text = EscPosReceiptBuilder.build_z_report(
            shift_number=f"X-{shift.shift_number}",
            opened_at=shift.opened_at.strftime("%d.%m.%Y %H:%M"),
            closed_at="HOZIRGI VAQT (OCHIQ)",
            cashier_name=request.user.full_name,
            starting_cash=shift.starting_cash,
            total_sales=shift.total_sales,
            cash_sales=shift.cash_sales,
            card_sales=shift.card_sales,
            app_sales=shift.app_sales,
            debt_sales=shift.debt_sales,
            cash_in=shift.cash_in,
            cash_out=shift.cash_out,
            actual_cash=expected,
            difference=decimal.Decimal('0.0'),
            orders_count=shift.orders_count,
        )
        return Response({
            'shift_id': str(shift.id),
            'expected_cash': float(expected),
            'total_sales': float(shift.total_sales),
            'report_text': x_text,
        })

    @action(methods=['post'], detail=True, url_path='cash-op')
    def cash_operation(self, request, pk=None):
        shift = self.get_object()
        op_type = request.data.get('operation_type')
        amount = decimal.Decimal(str(request.data.get('amount')))
        reason = request.data.get('reason', '')

        op = CashOperation.objects.create(
            company=shift.company,
            branch=shift.branch,
            shift=shift,
            operation_type=op_type,
            amount=amount,
            reason=reason,
            performed_by=request.user,
        )

        if op_type == 'CASH_IN':
            shift.cash_in += amount
        else:
            shift.cash_out += amount
        shift.save()

        return Response(CashOperationSerializer(op).data)


class ReceiptViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = ReceiptSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Receipt.objects.all()

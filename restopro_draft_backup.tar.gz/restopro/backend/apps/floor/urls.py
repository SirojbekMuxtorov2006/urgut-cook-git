from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.floor.views import HallViewSet, TableViewSet, ReservationViewSet

router = DefaultRouter()
router.register('halls', HallViewSet, basename='hall')
router.register('tables', TableViewSet, basename='table')
router.register('reservations', ReservationViewSet, basename='reservation')

urlpatterns = [
    path('', include(router.urls)),
]

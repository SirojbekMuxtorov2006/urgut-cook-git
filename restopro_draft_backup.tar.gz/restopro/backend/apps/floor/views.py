from rest_framework import serializers, viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from apps.floor.models import Hall, Table, Reservation, TableStatus
from apps.floor.services import FloorService

class TableSerializer(serializers.ModelSerializer):
    hall_name = serializers.CharField(source='hall.name', read_only=True)

    class Meta:
        model = Table
        fields = [
            'id', 'hall', 'hall_name', 'number', 'seats', 'status',
            'shape', 'pos_x', 'pos_y', 'width', 'height', 'current_order_id', 'is_active'
        ]


class HallSerializer(serializers.ModelSerializer):
    tables = TableSerializer(many=True, read_only=True)

    class Meta:
        model = Hall
        fields = ['id', 'name', 'sort_order', 'is_active', 'tables']


class ReservationSerializer(serializers.ModelSerializer):
    table_number = serializers.CharField(source='table.number', read_only=True)

    class Meta:
        model = Reservation
        fields = [
            'id', 'table', 'table_number', 'customer_name', 'customer_phone',
            'guests_count', 'reservation_time', 'deposit_amount', 'notes', 'is_cancelled'
        ]


class HallViewSet(viewsets.ModelViewSet):
    serializer_class = HallSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Hall.objects.filter(is_active=True).prefetch_related('tables')

    def perform_create(self, serializer):
        serializer.save(company=self.request.user.company, branch=self.request.user.branch)

    @action(methods=['post'], detail=True, url_path='update-layout')
    def update_layout(self, request, pk=None):
        tables_layout = request.data.get('tables', [])
        updated = FloorService.update_table_layout(hall_id=pk, tables_layout=tables_layout)
        return Response(TableSerializer(updated, many=True).data)


class TableViewSet(viewsets.ModelViewSet):
    serializer_class = TableSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = Table.objects.filter(is_active=True).select_related('hall')
        hall_id = self.request.query_params.get('hall_id')
        if hall_id:
            qs = qs.filter(hall_id=hall_id)
        return qs

    def perform_create(self, serializer):
        serializer.save(company=self.request.user.company, branch=self.request.user.branch)

    @action(methods=['post'], detail=True, url_path='set-status')
    def set_status(self, request, pk=None):
        new_status = request.data.get('status')
        order_id = request.data.get('order_id')
        if new_status not in TableStatus.values:
            return Response({'error': 'Noto\'g\'ri status'}, status=status.HTTP_400_BAD_REQUEST)
        table = FloorService.set_table_status(table_id=pk, new_status=new_status, order_id=order_id)
        return Response(TableSerializer(table).data)


class ReservationViewSet(viewsets.ModelViewSet):
    serializer_class = ReservationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Reservation.objects.filter(is_cancelled=False).select_related('table')

    def perform_create(self, serializer):
        serializer.save(company=self.request.user.company, branch=self.request.user.branch)

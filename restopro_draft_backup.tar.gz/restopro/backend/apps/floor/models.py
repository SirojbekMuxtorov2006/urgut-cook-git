from django.db import models
from apps.common.models import TenantBaseModel

class TableStatus(models.TextChoices):
    VACANT = 'VACANT', 'Bo\'sh'
    OCCUPIED = 'OCCUPIED', 'Band'
    BILL_REQUESTED = 'BILL_REQUESTED', 'Hisob so\'raldi'
    RESERVED = 'RESERVED', 'Bron qilingan'


class Hall(TenantBaseModel):
    name = models.CharField(max_length=150)
    sort_order = models.PositiveIntegerField(default=1)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Zal"
        verbose_name_plural = "Zallar"
        ordering = ['sort_order', 'name']

    def __str__(self):
        return f"{self.name} ({self.branch.name if self.branch else ''})"


class Table(TenantBaseModel):
    hall = models.ForeignKey(Hall, on_delete=models.CASCADE, related_name='tables')
    number = models.CharField(max_length=50, verbose_name="Stol raqami")
    seats = models.PositiveIntegerField(default=4, verbose_name="O'rindiqlar soni")
    status = models.CharField(max_length=30, choices=TableStatus.choices, default=TableStatus.VACANT)
    shape = models.CharField(max_length=30, default="rectangle") # round, rectangle, square
    pos_x = models.FloatField(default=0.0)
    pos_y = models.FloatField(default=0.0)
    width = models.FloatField(default=100.0)
    height = models.FloatField(default=100.0)
    current_order_id = models.UUIDField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Stol"
        verbose_name_plural = "Stollar"
        ordering = ['hall', 'number']

    def __str__(self):
        return f"Stol {self.number} ({self.hall.name}) - {self.get_status_display()}"


class Reservation(TenantBaseModel):
    table = models.ForeignKey(Table, on_delete=models.CASCADE, related_name='reservations')
    customer_name = models.CharField(max_length=255)
    customer_phone = models.CharField(max_length=32)
    guests_count = models.PositiveIntegerField(default=2)
    reservation_time = models.DateTimeField()
    deposit_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    notes = models.TextField(blank=True)
    is_cancelled = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.customer_name} - Stol {self.table.number} ({self.reservation_time})"

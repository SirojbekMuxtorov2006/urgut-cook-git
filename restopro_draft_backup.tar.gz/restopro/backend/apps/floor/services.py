from django.db import transaction
from django.utils import timezone
from apps.floor.models import Table, Hall, TableStatus, Reservation

class FloorService:
    @staticmethod
    @transaction.atomic
    def update_table_layout(hall_id: str, tables_layout: list) -> list:
        """
        Zaldagi stollarning koordinatalari va shaklini bir vaqtda saqlash (Drag & Drop muharriri).
        tables_layout: [{'id': '...', 'pos_x': 120.0, 'pos_y': 80.0, 'width': 100, 'height': 100, 'shape': 'rectangle'}, ...]
        """
        updated_tables = []
        for item in tables_layout:
            table_id = item.get('id')
            if not table_id:
                continue
            table = Table.objects.select_for_update().get(id=table_id, hall_id=hall_id)
            if 'pos_x' in item:
                table.pos_x = float(item['pos_x'])
            if 'pos_y' in item:
                table.pos_y = float(item['pos_y'])
            if 'width' in item:
                table.width = float(item['width'])
            if 'height' in item:
                table.height = float(item['height'])
            if 'shape' in item:
                table.shape = item['shape']
            table.save(update_fields=['pos_x', 'pos_y', 'width', 'height', 'shape', 'updated_at'])
            updated_tables.append(table)
        return updated_tables

    @staticmethod
    @transaction.atomic
    def set_table_status(table_id: str, new_status: str, order_id: str = None) -> Table:
        """
        Stol holatini o'zgartirish (VACANT, OCCUPIED, BILL_REQUESTED, RESERVED)
        va barcha qurilmalarga realtime tarqatish.
        """
        table = Table.objects.select_for_update().get(id=table_id)
        table.status = new_status
        if order_id is not None:
            table.current_order_id = order_id
        elif new_status == TableStatus.VACANT:
            table.current_order_id = None
        table.save(update_fields=['status', 'current_order_id', 'updated_at'])

        # Realtime WebSocket xabarnomasi
        try:
            from asgiref.sync import async_to_sync
            from channels.layers import get_channel_layer
            channel_layer = get_channel_layer()
            if channel_layer:
                async_to_sync(channel_layer.group_send)(
                    f"company_{table.company_id}",
                    {
                        "type": "table.status",
                        "table_id": str(table.id),
                        "table_number": table.number,
                        "status": table.status,
                        "current_order_id": str(table.current_order_id) if table.current_order_id else None,
                    }
                )
        except Exception:
            pass

        return table

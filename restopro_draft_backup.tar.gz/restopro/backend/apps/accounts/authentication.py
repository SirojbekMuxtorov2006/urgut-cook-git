from rest_framework import authentication, exceptions
from apps.tenancy.models import Device

class DeviceTokenAuthentication(authentication.BaseAuthentication):
    """
    Qurilmalarni 'X-Device-Token' sarlavhasi orqali autentifikatsiya qilish.
    """
    def authenticate(self, request):
        token = request.headers.get('X-Device-Token')
        if not token:
            return None

        try:
            device = Device.objects.select_related('company', 'branch').get(token=token, is_active=True)
        except Device.DoesNotExist:
            raise exceptions.AuthenticationFailed("Noto'g'ri yoki faol bo'lmagan qurilma tokeni")

        request.device = device
        # Agar foydalanuvchi hali kirmagan bo'lsa, device kontekst sifatida saqlanadi
        return (None, device)

import uuid
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from apps.common.utils.uuid import generate_uuidv7
from apps.tenancy.models import Company, Branch

class UserRole(models.TextChoices):
    OWNER = 'OWNER', 'Ega'
    MANAGER = 'MANAGER', 'Menejer'
    CASHIER = 'CASHIER', 'Kassir'
    WAITER = 'WAITER', 'Ofitsiant'
    CHEF = 'CHEF', 'Oshpaz'
    STOREKEEPER = 'STOREKEEPER', 'Omborchi'
    ACCOUNTANT = 'ACCOUNTANT', 'Buxgalter'
    COURIER = 'COURIER', 'Kuryer'


class UserManager(BaseUserManager):
    def create_user(self, phone, password=None, **extra_fields):
        if not phone:
            raise ValueError("Telefon raqami kiritilishi shart")
        phone = phone.strip()
        user = self.model(phone=phone, **extra_fields)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save(using=self._db)
        return user

    def create_superuser(self, phone, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('role', UserRole.OWNER)

        return self.create_user(phone, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    id = models.UUIDField(primary_key=True, default=generate_uuidv7, editable=False)
    phone = models.CharField(max_length=32, unique=True, verbose_name="Telefon raqam")
    full_name = models.CharField(max_length=255, verbose_name="F.I.O")
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='users'
    )
    branch = models.ForeignKey(
        Branch,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='users'
    )
    role = models.CharField(
        max_length=30,
        choices=UserRole.choices,
        default=UserRole.WAITER
    )
    pin_hash = models.CharField(max_length=128, blank=True, null=True, verbose_name="PIN-kod heshi")
    avatar_url = models.URLField(max_length=500, blank=True, null=True)

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

    USERNAME_FIELD = 'phone'
    REQUIRED_FIELDS = ['full_name']

    class Meta:
        verbose_name = "Foydalanuvchi"
        verbose_name_plural = "Foydalanuvchilar"

    def __str__(self):
        return f"{self.full_name} ({self.phone}) - {self.get_role_display()}"


class AuditLog(models.Model):
    id = models.UUIDField(primary_key=True, default=generate_uuidv7, editable=False)
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='audit_logs')
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    device = models.ForeignKey('tenancy.Device', on_delete=models.SET_NULL, null=True, blank=True)
    action = models.CharField(max_length=100)
    entity_name = models.CharField(max_length=100)
    entity_id = models.CharField(max_length=100, blank=True, null=True)
    details = models.JSONField(default=dict)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ['-created_at']

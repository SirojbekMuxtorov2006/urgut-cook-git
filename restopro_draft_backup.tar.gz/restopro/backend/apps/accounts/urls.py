from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from apps.accounts.views import (
    RegisterCompanyView,
    PinLoginView,
    DeviceRegisterView,
    MeView,
)

urlpatterns = [
    path('register/', RegisterCompanyView.as_view(), name='register-company'),
    path('login/', TokenObtainPairView.as_view(), name='token-obtain-pair'),
    path('login/pin/', PinLoginView.as_view(), name='pin-login'),
    path('refresh/', TokenRefreshView.as_view(), name='token-refresh'),
    path('me/', MeView.as_view(), name='user-me'),
    path('devices/register/', DeviceRegisterView.as_view(), name='device-register'),
]

import secrets
from django.utils.text import slugify
from django.contrib.auth.hashers import make_password
from django.utils import timezone
from datetime import timedelta
from rest_framework import status, views, permissions
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken

from apps.accounts.models import User, UserRole
from apps.accounts.serializers import (
    UserSerializer,
    RegisterCompanySerializer,
    PinLoginSerializer,
    DeviceRegisterSerializer,
)
from apps.tenancy.models import Company, Branch, Plan, Subscription, Device


class RegisterCompanyView(views.APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = RegisterCompanySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        slug = slugify(data['company_name'])
        if Company.objects.filter(slug=slug).exists():
            slug = f"{slug}-{secrets.token_hex(3)}"

        # 1. Kompaniya yaratish
        company = Company.objects.create(
            name=data['company_name'],
            slug=slug,
            business_type=data['business_type'],
            phone=data['owner_phone']
        )

        # 2. Bosh filial
        branch = Branch.objects.create(
            company=company,
            name=data['branch_name'],
            phone=data['owner_phone']
        )

        # 3. Sinov tarifi (Trial)
        plan, _ = Plan.objects.get_or_create(
            code='standard',
            defaults={
                'name': 'Standard RestoPro',
                'price_monthly': 290000,
                'max_branches': 1,
                'max_pos_devices': 2,
                'max_waiter_devices': 5,
                'max_kds_devices': 2,
                'features': {'kds': True, 'recipes': True, 'qr_menu': True}
            }
        )

        Subscription.objects.create(
            company=company,
            plan=plan,
            status=Subscription.Status.TRIAL,
            expires_at=timezone.now() + timedelta(days=14)
        )

        # 4. Ega (Owner) foydalanuvchisi
        owner = User.objects.create_user(
            phone=data['owner_phone'],
            password=data['owner_password'],
            full_name=data['owner_name'],
            company=company,
            branch=branch,
            role=UserRole.OWNER,
            pin_hash=make_password(data['owner_pin']),
            is_staff=True
        )

        refresh = RefreshToken.for_user(owner)
        refresh['company_id'] = str(company.id)
        refresh['branch_id'] = str(branch.id)
        refresh['role'] = owner.role

        return Response({
            'message': "RestoPro SaaS tizimida muvaffaqiyatli ro'yxatdan o'tdingiz!",
            'company': {
                'id': str(company.id),
                'name': company.name,
                'slug': company.slug,
            },
            'branch': {
                'id': str(branch.id),
                'name': branch.name,
            },
            'user': UserSerializer(owner).data,
            'tokens': {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            }
        }, status=status.HTTP_201_CREATED)


class PinLoginView(views.APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = PinLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']

        refresh = RefreshToken.for_user(user)
        if user.company_id:
            refresh['company_id'] = str(user.company_id)
        if user.branch_id:
            refresh['branch_id'] = str(user.branch_id)
        refresh['role'] = user.role

        return Response({
            'user': UserSerializer(user).data,
            'tokens': {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            }
        })


class DeviceRegisterView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = DeviceRegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        branch = Branch.objects.get(id=data['branch_id'], company=request.user.company)
        token = f"dev_{secrets.token_urlsafe(32)}"

        device, _ = Device.objects.update_or_create(
            device_code=data['device_code'],
            defaults={
                'company': request.user.company,
                'branch': branch,
                'name': data['name'],
                'mode': data['mode'],
                'token': token,
                'is_active': True,
                'last_seen_at': timezone.now()
            }
        )

        return Response({
            'id': str(device.id),
            'name': device.name,
            'device_code': device.device_code,
            'mode': device.mode,
            'device_token': device.token,
            'branch_id': str(branch.id),
        }, status=status.HTTP_201_CREATED)


class MeView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data)

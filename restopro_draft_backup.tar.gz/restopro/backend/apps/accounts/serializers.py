from rest_framework import serializers
from django.contrib.auth import authenticate
from django.contrib.auth.hashers import check_password, make_password
from apps.accounts.models import User, UserRole
from apps.tenancy.models import Company, Branch, Device, DeviceMode

class UserSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(source='company.name', read_only=True)
    branch_name = serializers.CharField(source='branch.name', read_only=True)

    class Meta:
        model = User
        fields = [
            'id', 'phone', 'full_name', 'role', 'company', 'company_name',
            'branch', 'branch_name', 'avatar_url', 'is_active'
        ]
        read_only_fields = ['id', 'company', 'branch']


class RegisterCompanySerializer(serializers.Serializer):
    company_name = serializers.CharField(max_length=255)
    business_type = serializers.CharField(max_length=50)
    branch_name = serializers.CharField(max_length=255, default="Bosh filial")
    owner_phone = serializers.CharField(max_length=32)
    owner_name = serializers.CharField(max_length=255)
    owner_password = serializers.CharField(write_only=True, min_length=6)
    owner_pin = serializers.CharField(write_only=True, min_length=4, max_length=4, default="1111")


class PinLoginSerializer(serializers.Serializer):
    pin = serializers.CharField(max_length=4, min_length=4)
    branch_id = serializers.UUIDField(required=False)
    device_token = serializers.CharField(required=False)

    def validate(self, attrs):
        pin = attrs.get('pin')
        branch_id = attrs.get('branch_id')

        # Tegishli filialdagi faol foydalanuvchilar orasidan PIN tekshirish
        users = User.objects.filter(is_active=True).exclude(pin_hash__isnull=True)
        if branch_id:
            users = users.filter(branch_id=branch_id)

        matched_user = None
        for user in users:
            if check_password(pin, user.pin_hash):
                matched_user = user
                break

        if not matched_user:
            raise serializers.ValidationError("Kiritilgan PIN-kod noto'g'ri!")

        attrs['user'] = matched_user
        return attrs


class DeviceRegisterSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=150)
    mode = serializers.ChoiceField(choices=DeviceMode.choices, default=DeviceMode.POS)
    branch_id = serializers.UUIDField()
    device_code = serializers.CharField(max_length=64)

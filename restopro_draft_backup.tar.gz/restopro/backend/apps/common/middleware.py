from django.utils.deprecation import MiddlewareMixin
from apps.common.models import set_current_tenant, clear_current_tenant

class TenantMiddleware(MiddlewareMixin):
    """
    Har bir so'rovdan kompaniya (tenant) ID sini oladi va thread local'ga o'rnatadi.
    1. Agar foydalanuvchi tizimga kirgan bo'lsa (JWT / Session), uning user.company_id si olinadi.
    2. Agar qurilma orqali murojaat bo'lsa (X-Device-Token), qurilmaning company_id si olinadi.
    3. Agar Superadmin bo'lsa, 'X-Company-ID' header orqali istalgan kompaniyani boshqara oladi.
    """
    def process_request(self, request):
        company_id = None
        user = getattr(request, 'user', None)

        if user and user.is_authenticated:
            if user.is_superuser and 'HTTP_X_COMPANY_ID' in request.META:
                company_id = request.META['HTTP_X_COMPANY_ID']
            else:
                company_id = getattr(user, 'company_id', None)
        elif hasattr(request, 'device') and request.device:
            company_id = request.device.company_id

        if company_id:
            set_current_tenant(company_id)
            request.company_id = company_id
        else:
            clear_current_tenant()
            request.company_id = None

    def process_response(self, request, response):
        clear_current_tenant()
        return response

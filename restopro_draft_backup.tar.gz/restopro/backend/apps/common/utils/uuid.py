import time
import os
import uuid

def generate_uuidv7() -> uuid.UUID:
    """
    UUIDv7 generator (RFC 9562).
    Millisekund timestamp (48 bit) + tasodifiy baytlar (74 bit) + versiya/variant.
    """
    msecs = int(time.time() * 1000)
    rand_bytes = os.urandom(10)
    
    # 48-bit timestamp
    time_high = (msecs >> 16) & 0xFFFFFFFF
    time_mid = msecs & 0xFFFF
    
    # 12-bit rand_a + version (7)
    time_hi_and_version = 0x7000 | (int.from_bytes(rand_bytes[:2], 'big') & 0x0FFF)
    
    # 2-bit variant (10xx) + 62-bit rand_b
    clk_seq_hi_res = 0x80 | (rand_bytes[2] & 0x3F)
    clk_seq_low = rand_bytes[3]
    node = int.from_bytes(rand_bytes[4:], 'big')
    
    int_val = (
        (time_high << 96)
        | (time_mid << 80)
        | (time_hi_and_version << 64)
        | (clk_seq_hi_res << 56)
        | (clk_seq_low << 48)
        | node
    )
    return uuid.UUID(int=int_val)

import threading
from django.db import models
from django.conf import settings
from apps.common.utils.uuid import generate_uuidv7

_thread_locals = threading.local()

def set_current_tenant(company_id):
    _thread_locals.company_id = company_id

def get_current_tenant():
    return getattr(_thread_locals, 'company_id', None)

def clear_current_tenant():
    if hasattr(_thread_locals, 'company_id'):
        del _thread_locals.company_id


class TenantQuerySet(models.QuerySet):
    def filter_by_current_tenant(self):
        company_id = get_current_tenant()
        if company_id:
            return self.filter(company_id=company_id)
        return self

    def delete(self):
        # Soft delete
        from django.utils import timezone
        return self.update(deleted_at=timezone.now())

    def hard_delete(self):
        return super().delete()


class TenantManager(models.Manager):
    def get_queryset(self):
        qs = TenantQuerySet(self.model, using=self._db).filter(deleted_at__isnull=True)
        company_id = get_current_tenant()
        if company_id and hasattr(self.model, 'company'):
            return qs.filter(company_id=company_id)
        return qs

    def all_with_deleted(self):
        return TenantQuerySet(self.model, using=self._db)


class TenantBaseModel(models.Model):
    id = models.UUIDField(primary_key=True, default=generate_uuidv7, editable=False)
    company = models.ForeignKey(
        'tenancy.Company',
        on_delete=models.CASCADE,
        related_name='%(class)s_company',
        db_index=True
    )
    branch = models.ForeignKey(
        'tenancy.Branch',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='%(class)s_branch',
        db_index=True
    )
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True, db_index=True)
    deleted_at = models.DateTimeField(null=True, blank=True, db_index=True)
    version = models.PositiveIntegerField(default=1)
    
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='%(class)s_created_by'
    )
    device = models.ForeignKey(
        'tenancy.Device',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='%(class)s_device'
    )

    objects = TenantManager()
    all_objects = models.Manager()

    class Meta:
        abstract = True
        indexes = [
            models.Index(fields=['company', 'updated_at']),
        ]

    def delete(self, using=None, keep_parents=False):
        from django.utils import timezone
        self.deleted_at = timezone.now()
        self.save(update_fields=['deleted_at'])

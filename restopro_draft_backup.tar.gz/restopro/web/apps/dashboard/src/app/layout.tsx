import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'RestoPro - SaaS Restoran Boshqaruv Paneli',
  description: 'Restoran, oshxona va kafe boshqaruvi',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="uz">
      <body className="bg-slate-950 text-slate-100 min-h-screen">
        {children}
      </body>
    </html>
  );
}

'use client';

import React, { useState } from 'react';
import {
  UtensilsCrossed,
  Plus,
  Search,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Store,
  Receipt,
  Users,
  ChefHat,
  Filter,
} from 'lucide-react';

interface MenuItem {
  id: string;
  name: string;
  category: string;
  station: string;
  price: number;
  costPrice: number;
  unit: string;
  isAvailable: boolean;
  isPopular: boolean;
}

const initialItems: MenuItem[] = [
  { id: '1', name: "To'y Oshi (Toshkentcha)", category: 'Ikkinchi taomlar', station: 'Issiq sex', price: 38000, costPrice: 18500, unit: 'pors', isAvailable: true, isPopular: true },
  { id: '2', name: "Sho'rva (Qo'y go'shtli)", category: 'Birinchi taomlar', station: 'Issiq sex', price: 42000, costPrice: 22000, unit: 'pors', isAvailable: true, isPopular: false },
  { id: '3', name: 'Qozon Kabob (Mol)', category: 'Ikkinchi taomlar', station: 'Issiq sex', price: 65000, costPrice: 34000, unit: 'pors', isAvailable: false, isPopular: true },
  { id: '4', name: 'Qiyma Shashlik', category: 'Kavob va Gril', station: 'Issiq sex', price: 22000, costPrice: 10500, unit: 'dona', isAvailable: true, isPopular: true },
  { id: '5', name: 'Tandir Somsa (Go\'shtli)', category: 'Somsa va Non', station: 'Somsa tandiri', price: 14000, costPrice: 6500, unit: 'dona', isAvailable: true, isPopular: true },
  { id: '6', name: 'Achchiq-chuchuk', category: 'Salatlar', station: 'Bar va Salatlar', price: 15000, costPrice: 4500, unit: 'pors', isAvailable: true, isPopular: false },
  { id: '7', name: 'Ko\'k Choy (Choynak)', category: 'Ichimliklar', station: 'Bar va Salatlar', price: 6000, costPrice: 800, unit: 'dona', isAvailable: true, isPopular: false },
];

export default function MenuManagementPage() {
  const [items, setItems] = useState<MenuItem[]>(initialItems);
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('Hammasi');

  const categories = ['Hammasi', 'Birinchi taomlar', 'Ikkinchi taomlar', 'Kavob va Gril', 'Somsa va Non', 'Salatlar', 'Ichimliklar'];

  const toggleStopList = (id: string) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, isAvailable: !item.isAvailable } : item
      )
    );
  };

  const filtered = items.filter((item) => {
    const matchesCat = selectedCat === 'Hammasi' || item.category === selectedCat;
    const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-100">
      {/* Sidebar */}
      <aside className="w-64 border-r border-slate-800 bg-slate-900/60 p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-3 mb-8">
            <div className="p-2 rounded-xl bg-orange-500/10 text-orange-500 border border-orange-500/20">
              <UtensilsCrossed className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-white">RestoPro</h1>
              <span className="text-xs text-orange-400 font-medium">SaaS Cloud v1.0</span>
            </div>
          </div>
          <nav className="space-y-1">
            <a href="/" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <TrendingUp className="w-4 h-4" /> Boshqaruv
            </a>
            <a href="/menu" className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-orange-500 text-white font-medium text-sm">
              <ChefHat className="w-4 h-4" /> Menyu & Retseptlar
            </a>
            <a href="/tables" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <Store className="w-4 h-4" /> Zallar & Stollar
            </a>
            <a href="/reports" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <Receipt className="w-4 h-4" /> Sotuv & Hisobotlar
            </a>
            <a href="/staff" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <Users className="w-4 h-4" /> Xodimlar & PIN
            </a>
          </nav>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 space-y-6 overflow-y-auto">
        <header className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-white">Menyu & Retseptlar Boshqaruvi</h2>
            <p className="text-slate-400 text-sm">Taomlar narxi, sexlar, kalkulyatsiya tannarxi va Stop-list</p>
          </div>
          <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 font-semibold text-sm transition">
            <Plus className="w-4 h-4" /> Yangi Taom Qo&apos;shish
          </button>
        </header>

        {/* Filter & Search Bar */}
        <div className="flex gap-4 items-center bg-slate-900 p-3 rounded-2xl border border-slate-800">
          <div className="flex-1 flex items-center gap-2 px-3 py-2 bg-slate-950 rounded-xl border border-slate-800">
            <Search className="w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Taom nomini qidirish..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-transparent border-none outline-none text-sm w-full text-white placeholder-slate-500"
            />
          </div>
          <div className="flex gap-1.5 overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCat(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition ${
                  selectedCat === cat
                    ? 'bg-orange-500 text-white'
                    : 'bg-slate-800/60 text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Table of Dishes */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-800/50 text-slate-400 border-b border-slate-800 font-medium">
              <tr>
                <th className="p-4">Taom nomi</th>
                <th className="p-4">Kategoriya & Sex</th>
                <th className="p-4">Sotuv narxi</th>
                <th className="p-4">Tannarxi (Food cost)</th>
                <th className="p-4">Marja %</th>
                <th className="p-4">Holat (Stop-list)</th>
                <th className="p-4 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((item) => {
                const marginPercent = Math.round(((item.price - item.costPrice) / item.price) * 100);
                const foodCostPercent = Math.round((item.costPrice / item.price) * 100);

                return (
                  <tr key={item.id} className="hover:bg-slate-800/30 transition">
                    <td className="p-4 font-semibold text-white">
                      <div className="flex items-center gap-2">
                        {item.name}
                        {item.isPopular && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                            TOP
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <p className="text-white text-xs font-medium">{item.category}</p>
                      <p className="text-slate-400 text-[11px]">{item.station}</p>
                    </td>
                    <td className="p-4 font-bold text-orange-400">
                      {item.price.toLocaleString()} so&apos;m
                    </td>
                    <td className="p-4 text-slate-300">
                      {item.costPrice.toLocaleString()} so&apos;m ({foodCostPercent}%)
                    </td>
                    <td className="p-4">
                      <span className="font-semibold text-emerald-400">
                        {marginPercent}%
                      </span>
                    </td>
                    <td className="p-4">
                      <button
                        onClick={() => toggleStopList(item.id)}
                        className={`px-3 py-1 rounded-full text-xs font-semibold transition ${
                          item.isAvailable
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20'
                            : 'bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20'
                        }`}
                      >
                        {item.isAvailable ? '🟢 Sotuvda' : '🔴 Stop-list'}
                      </button>
                    </td>
                    <td className="p-4 text-right">
                      <button className="text-xs text-orange-400 hover:text-orange-300 font-medium">
                        Tahrirlash & Retsept
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}

'use client';

import React, { useState } from 'react';
import {
  UtensilsCrossed,
  Receipt,
  Store,
  TrendingUp,
  Users,
  ChefHat,
  AlertOctagon,
  Download,
  Calendar,
  DollarSign,
  CreditCard,
  Phone,
} from 'lucide-react';

export default function ReportsAndShiftsPage() {
  const [activeTab, setActiveTab] = useState<'shifts' | 'voids'>('shifts');

  const sampleShifts = [
    {
      id: 'S-0045',
      cashier: 'Dilshod Aliyev',
      openedAt: '20.11.2026 08:30',
      closedAt: '20.11.2026 23:15',
      startingCash: 300000,
      totalSales: 14850000,
      cashSales: 8200000,
      cardSales: 4650000,
      appSales: 2000000,
      ordersCount: 164,
      difference: 0,
    },
    {
      id: 'S-0044',
      cashier: 'Nodira Karimova',
      openedAt: '19.11.2026 08:30',
      closedAt: '19.11.2026 23:00',
      startingCash: 300000,
      totalSales: 13200000,
      cashSales: 7400000,
      cardSales: 4100000,
      appSales: 1700000,
      ordersCount: 148,
      difference: -15000, // 15 000 so'm kamomad
    },
  ];

  const sampleVoids = [
    {
      id: 'V-102',
      time: '20.11.2026 14:12',
      table: 'Stol 7',
      dish: 'Manti (Go\'shtli) x 2',
      amount: 84000,
      waiter: 'Aziz Bekzodov',
      approvedBy: 'Sardor Qodirov (Menejer)',
      reason: 'Mijoz 40 daqiqa kutdi va ketib qoldi',
    },
    {
      id: 'V-101',
      time: '20.11.2026 12:45',
      table: 'Stol 3',
      dish: 'Qozon Kabob x 1',
      amount: 65000,
      waiter: 'Bobur Mirzayev',
      approvedBy: 'Akrom Rahimov (Ega)',
      reason: 'Ofitsiant xato urdi (oshxonaga chiqmagan)',
    },
  ];

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-100">
      {/* Sidebar */}
      <aside className="w-64 border-r border-slate-800 bg-slate-900/60 p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-3 mb-8">
            <div className="p-2 rounded-xl bg-orange-500/10 text-orange-500 border border-orange-500/20">
              <UtensilsCrossed className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-white">RestoPro</h1>
              <span className="text-xs text-orange-400 font-medium">SaaS Cloud v1.0</span>
            </div>
          </div>
          <nav className="space-y-1">
            <a href="/" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <TrendingUp className="w-4 h-4" /> Boshqaruv
            </a>
            <a href="/menu" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <ChefHat className="w-4 h-4" /> Menyu & Retseptlar
            </a>
            <a href="/tables" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <Store className="w-4 h-4" /> Zallar & Stollar
            </a>
            <a href="/reports" className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-orange-500 text-white font-medium text-sm">
              <Receipt className="w-4 h-4" /> Sotuv & Hisobotlar
            </a>
            <a href="/staff" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <Users className="w-4 h-4" /> Xodimlar & PIN
            </a>
          </nav>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 space-y-6 overflow-y-auto">
        <header className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-white">Smena Hisobotlari va Audit Nazorati</h2>
            <p className="text-slate-400 text-sm">Z-hisobotlar, to&apos;lov turlari, kassa farqlari va bekor qilingan taomlar (Voids)</p>
          </div>
          <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-semibold hover:text-white transition">
            <Download className="w-4 h-4" /> Excel Eksport
          </button>
        </header>

        {/* Tab tanlash */}
        <div className="flex gap-2 border-b border-slate-800 pb-3">
          <button
            onClick={() => setActiveTab('shifts')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition ${
              activeTab === 'shifts'
                ? 'bg-slate-800 text-white border border-slate-700'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            💰 Smenalar & Z-Hisobotlar
          </button>
          <button
            onClick={() => setActiveTab('voids')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition ${
              activeTab === 'voids'
                ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            ⚠️ Bekor qilingan taomlar (Voids Audit)
          </button>
        </div>

        {activeTab === 'shifts' ? (
          <div className="space-y-4">
            <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-800/50 text-slate-400 border-b border-slate-800 font-medium">
                  <tr>
                    <th className="p-4">Smena №</th>
                    <th className="p-4">Kassir</th>
                    <th className="p-4">Ochildi / Yopildi</th>
                    <th className="p-4">Cheklar</th>
                    <th className="p-4">Naqd pul</th>
                    <th className="p-4">Karta / Ilova</th>
                    <th className="p-4">Jami tushum</th>
                    <th className="p-4">Kassa farqi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {sampleShifts.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-800/30 transition">
                      <td className="p-4 font-bold text-white">{s.id}</td>
                      <td className="p-4 text-white font-medium">{s.cashier}</td>
                      <td className="p-4 text-xs text-slate-400">
                        <p>{s.openedAt}</p>
                        <p>{s.closedAt}</p>
                      </td>
                      <td className="p-4 font-semibold text-white">{s.ordersCount} ta</td>
                      <td className="p-4 text-emerald-400 font-bold">{s.cashSales.toLocaleString()} so&apos;m</td>
                      <td className="p-4 text-blue-400 font-bold">{(s.cardSales + s.appSales).toLocaleString()} so&apos;m</td>
                      <td className="p-4 text-orange-400 font-bold text-base">{s.totalSales.toLocaleString()} so&apos;m</td>
                      <td className="p-4">
                        {s.difference === 0 ? (
                          <span className="text-xs text-emerald-400 font-bold">0 so&apos;m (Aniq)</span>
                        ) : (
                          <span className="text-xs text-red-400 font-bold">{s.difference.toLocaleString()} so&apos;m</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-300 flex items-center gap-3">
              <AlertOctagon className="w-5 h-5 flex-shrink-0 text-red-400" />
              <span>
                <strong>O&apos;g&apos;rilikka qarshi nazorat:</strong> Oshxonaga yuborilgan har bir bekor qilingan taom faqat Menejer/Ega PIN tasdig&apos;i bilan amalga oshiriladi va isrof hisobiga kiritiladi.
              </span>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-800/50 text-slate-400 border-b border-slate-800 font-medium">
                  <tr>
                    <th className="p-4">Vaqt & Stol</th>
                    <th className="p-4">Bekor qilingan taom</th>
                    <th className="p-4">Summasi</th>
                    <th className="p-4">Ofitsiant</th>
                    <th className="p-4">Tasdiqladi (Admin/PIN)</th>
                    <th className="p-4">Sababi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {sampleVoids.map((v) => (
                    <tr key={v.id} className="hover:bg-slate-800/30 transition">
                      <td className="p-4">
                        <p className="font-bold text-white">{v.table}</p>
                        <p className="text-xs text-slate-400">{v.time}</p>
                      </td>
                      <td className="p-4 font-semibold text-white">{v.dish}</td>
                      <td className="p-4 font-bold text-red-400">-{v.amount.toLocaleString()} so&apos;m</td>
                      <td className="p-4 text-slate-300">{v.waiter}</td>
                      <td className="p-4 text-orange-400 font-medium">{v.approvedBy}</td>
                      <td className="p-4 text-xs text-slate-300 italic">{v.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

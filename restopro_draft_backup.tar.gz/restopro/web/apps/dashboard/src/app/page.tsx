import React from 'react';
import {
  Store,
  DollarSign,
  TrendingUp,
  Receipt,
  Users,
  UtensilsCrossed,
  ChefHat,
  ShieldCheck,
} from 'lucide-react';

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen">
      {/* Yon menyu (Sidebar) */}
      <aside className="w-64 border-r border-slate-800 bg-slate-900/60 p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-3 mb-8">
            <div className="p-2 rounded-xl bg-orange-500/10 text-orange-500 border border-orange-500/20">
              <UtensilsCrossed className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-white">RestoPro</h1>
              <span className="text-xs text-orange-400 font-medium">SaaS Cloud v1.0</span>
            </div>
          </div>

          <nav className="space-y-1">
            <a href="/" className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-orange-500 text-white font-medium text-sm">
              <TrendingUp className="w-4 h-4" /> Boshqaruv
            </a>
            <a href="/menu" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <ChefHat className="w-4 h-4" /> Menyu & Retseptlar
            </a>
            <a href="/tables" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <Store className="w-4 h-4" /> Zallar & Stollar
            </a>
            <a href="/reports" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <Receipt className="w-4 h-4" /> Sotuv & Hisobotlar
            </a>
            <a href="/staff" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <Users className="w-4 h-4" /> Xodimlar & PIN
            </a>
          </nav>
        </div>

        <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50 flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold text-sm">
            AR
          </div>
          <div>
            <p className="text-sm font-medium text-white">Akrom Rahimov</p>
            <p className="text-xs text-slate-400">Restoran Egasi</p>
          </div>
        </div>
      </aside>

      {/* Asosiy panel */}
      <main className="flex-1 p-8 space-y-8 overflow-y-auto">
        <header className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-white">Chorsu Milliy Taomlar Markazi</h2>
            <p className="text-slate-400 text-sm">Bosh Filial · Toshkent sh., Navoiy ko&apos;chasi 42</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="w-3.5 h-3.5" />
              SaaS Obuna: Faol (90 kun)
            </span>
          </div>
        </header>

        {/* 4 ta asosiy ko'rsatkichlar kartochkasi */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
            <div className="flex justify-between items-center text-slate-400 mb-2">
              <span className="text-sm">Bugungi tushum</span>
              <DollarSign className="w-5 h-5 text-emerald-400" />
            </div>
            <p className="text-2xl font-bold text-white">14 850 000 so&apos;m</p>
            <span className="text-xs text-emerald-400">↑ Kechagiga nisbatan +12%</span>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
            <div className="flex justify-between items-center text-slate-400 mb-2">
              <span className="text-sm">Cheklar soni</span>
              <Receipt className="w-5 h-5 text-blue-400" />
            </div>
            <p className="text-2xl font-bold text-white">164 ta</p>
            <span className="text-xs text-slate-400">O&apos;rtacha chek: 90 500 so&apos;m</span>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
            <div className="flex justify-between items-center text-slate-400 mb-2">
              <span className="text-sm">Band stollar</span>
              <Store className="w-5 h-5 text-orange-400" />
            </div>
            <p className="text-2xl font-bold text-white">14 / 20 ta</p>
            <span className="text-xs text-orange-400">70% zal to&apos;lgan</span>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
            <div className="flex justify-between items-center text-slate-400 mb-2">
              <span className="text-sm">Food Cost %</span>
              <ChefHat className="w-5 h-5 text-yellow-400" />
            </div>
            <p className="text-2xl font-bold text-white">31.4%</p>
            <span className="text-xs text-emerald-400">Me&apos;yorda (max 35%)</span>
          </div>
        </div>

        {/* Faol qurilmalar va joriy smena */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <h3 className="font-bold text-lg mb-4 text-white">Ulangan Qurilmalar (Lokal Hub)</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-800/50">
                <div className="flex items-center gap-3">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <div>
                    <p className="font-medium text-sm text-white">Asosiy Kassa (Hub #1)</p>
                    <p className="text-xs text-slate-400">Flutter Windows · 192.168.1.10:8787</p>
                  </div>
                </div>
                <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Lokal Hub</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-800/50">
                <div className="flex items-center gap-3">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  <div>
                    <p className="font-medium text-sm text-white">Oshxona KDS Ekrani</p>
                    <p className="text-xs text-slate-400">Android TV · 192.168.1.25</p>
                  </div>
                </div>
                <span className="text-xs px-2.5 py-1 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">KDS Faol</span>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <h3 className="font-bold text-lg mb-4 text-white">Sotuv yetakchilari (TOP 5)</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-sm">
                <span className="text-white">1. To&apos;y Oshi (1 porsiya)</span>
                <span className="font-bold text-orange-400">84 porsiya</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-white">2. Qiyma Shashlik</span>
                <span className="font-bold text-orange-400">62 dona</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-white">3. Tandir Somsa</span>
                <span className="font-bold text-orange-400">45 dona</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-white">4. Sho&apos;rva (Qo&apos;y go&apos;shtli)</span>
                <span className="font-bold text-orange-400">38 porsiya</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-white">5. Achchiq-chuchuk</span>
                <span className="font-bold text-orange-400">35 porsiya</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

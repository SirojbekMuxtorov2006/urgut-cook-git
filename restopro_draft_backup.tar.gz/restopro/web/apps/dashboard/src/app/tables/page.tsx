'use client';

import React, { useState } from 'react';
import {
  UtensilsCrossed,
  Plus,
  Store,
  TrendingUp,
  Receipt,
  Users,
  ChefHat,
  Move,
  CheckCircle2,
} from 'lucide-react';

interface TableModel {
  id: string;
  hallId: string;
  number: string;
  seats: number;
  status: 'VACANT' | 'OCCUPIED' | 'BILL_REQUESTED' | 'RESERVED';
  shape: 'rectangle' | 'round';
  posX: number;
  posY: number;
  currentAmount?: number;
}

const initialTables: TableModel[] = [
  // Asosiy zal (12 stol)
  { id: '1', hallId: 'h1', number: '1', seats: 4, status: 'OCCUPIED', shape: 'rectangle', posX: 30, posY: 30, currentAmount: 145000 },
  { id: '2', hallId: 'h1', number: '2', seats: 4, status: 'VACANT', shape: 'rectangle', posX: 170, posY: 30 },
  { id: '3', hallId: 'h1', number: '3', seats: 4, status: 'BILL_REQUESTED', shape: 'rectangle', posX: 310, posY: 30, currentAmount: 84000 },
  { id: '4', hallId: 'h1', number: '4', seats: 4, status: 'VACANT', shape: 'rectangle', posX: 450, posY: 30 },
  { id: '5', hallId: 'h1', number: '5', seats: 4, status: 'VACANT', shape: 'rectangle', posX: 30, posY: 170 },
  { id: '6', hallId: 'h1', number: '6', seats: 4, status: 'OCCUPIED', shape: 'rectangle', posX: 170, posY: 170, currentAmount: 230000 },
  { id: '7', hallId: 'h1', number: '7', seats: 6, status: 'RESERVED', shape: 'round', posX: 310, posY: 170 },
  { id: '8', hallId: 'h1', number: '8', seats: 6, status: 'VACANT', shape: 'round', posX: 450, posY: 170 },
  { id: '9', hallId: 'h1', number: '9', seats: 6, status: 'OCCUPIED', shape: 'rectangle', posX: 30, posY: 310, currentAmount: 92000 },
  { id: '10', hallId: 'h1', number: '10', seats: 6, status: 'VACANT', shape: 'rectangle', posX: 170, posY: 310 },
  { id: '11', hallId: 'h1', number: '11', seats: 8, status: 'VACANT', shape: 'rectangle', posX: 310, posY: 310 },
  { id: '12', hallId: 'h1', number: '12', seats: 8, status: 'OCCUPIED', shape: 'rectangle', posX: 450, posY: 310, currentAmount: 410000 },

  // Yozgi ayvon (8 stol)
  { id: '13', hallId: 'h2', number: '13', seats: 6, status: 'VACANT', shape: 'round', posX: 40, posY: 40 },
  { id: '14', hallId: 'h2', number: '14', seats: 6, status: 'OCCUPIED', shape: 'round', posX: 200, posY: 40, currentAmount: 180000 },
  { id: '15', hallId: 'h2', number: '15', seats: 6, status: 'VACANT', shape: 'round', posX: 360, posY: 40 },
  { id: '16', hallId: 'h2', number: '16', seats: 6, status: 'VACANT', shape: 'round', posX: 520, posY: 40 },
  { id: '17', hallId: 'h2', number: '17', seats: 8, status: 'OCCUPIED', shape: 'rectangle', posX: 40, posY: 200, currentAmount: 320000 },
  { id: '18', hallId: 'h2', number: '18', seats: 8, status: 'VACANT', shape: 'rectangle', posX: 200, posY: 200 },
  { id: '19', hallId: 'h2', number: '19', seats: 8, status: 'VACANT', shape: 'rectangle', posX: 360, posY: 200 },
  { id: '20', hallId: 'h2', number: '20', seats: 8, status: 'VACANT', shape: 'rectangle', posX: 520, posY: 200 },
];

export default function TablesFloorPlanPage() {
  const [selectedHall, setSelectedHall] = useState<'h1' | 'h2'>('h1');
  const [tables, setTables] = useState<TableModel[]>(initialTables);
  const [selectedTable, setSelectedTable] = useState<TableModel | null>(null);
  const [isEditMode, setIsEditMode] = useState(false);

  const activeHallTables = tables.filter((t) => t.hallId === selectedHall);

  const getStatusBadge = (status: TableModel['status']) => {
    switch (status) {
      case 'VACANT':
        return <span className="text-emerald-400 font-bold text-xs">🟢 Bo&apos;sh</span>;
      case 'OCCUPIED':
        return <span className="text-red-400 font-bold text-xs">🔴 Band</span>;
      case 'BILL_REQUESTED':
        return <span className="text-yellow-400 font-bold text-xs">🟡 Hisob so&apos;raldi</span>;
      case 'RESERVED':
        return <span className="text-blue-400 font-bold text-xs">🔵 Bron</span>;
    }
  };

  const getStatusBorder = (status: TableModel['status']) => {
    switch (status) {
      case 'VACANT':
        return 'border-emerald-500/40 bg-emerald-500/10 hover:border-emerald-500';
      case 'OCCUPIED':
        return 'border-red-500/50 bg-red-500/15 hover:border-red-500';
      case 'BILL_REQUESTED':
        return 'border-yellow-500/50 bg-yellow-500/15 hover:border-yellow-500';
      case 'RESERVED':
        return 'border-blue-500/50 bg-blue-500/15 hover:border-blue-500';
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-100">
      {/* Sidebar */}
      <aside className="w-64 border-r border-slate-800 bg-slate-900/60 p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-3 mb-8">
            <div className="p-2 rounded-xl bg-orange-500/10 text-orange-500 border border-orange-500/20">
              <UtensilsCrossed className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-white">RestoPro</h1>
              <span className="text-xs text-orange-400 font-medium">SaaS Cloud v1.0</span>
            </div>
          </div>
          <nav className="space-y-1">
            <a href="/" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <TrendingUp className="w-4 h-4" /> Boshqaruv
            </a>
            <a href="/menu" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <ChefHat className="w-4 h-4" /> Menyu & Retseptlar
            </a>
            <a href="/tables" className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-orange-500 text-white font-medium text-sm">
              <Store className="w-4 h-4" /> Zallar & Stollar
            </a>
            <a href="/reports" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <Receipt className="w-4 h-4" /> Sotuv & Hisobotlar
            </a>
            <a href="/staff" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 text-sm">
              <Users className="w-4 h-4" /> Xodimlar & PIN
            </a>
          </nav>
        </div>
      </aside>

      {/* Main Floor Plan Area */}
      <main className="flex-1 p-8 space-y-6 flex flex-col">
        <header className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-white">Zallar & Stollar Vizual Xaritasi</h2>
            <p className="text-slate-400 text-sm">Stollar joylashuvi, real vaqt holati va bandlik darajasi</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsEditMode(!isEditMode)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-semibold transition ${
                isEditMode
                  ? 'bg-orange-500 text-white border-orange-500'
                  : 'bg-slate-900 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <Move className="w-4 h-4" /> {isEditMode ? "Tahrirni Saqlash" : "Xaritani Tahrirlash (Drag & Drop)"}
            </button>
            <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 font-semibold text-sm transition">
              <Plus className="w-4 h-4" /> Stol Qo&apos;shish
            </button>
          </div>
        </header>

        {/* Zal tanlash tugmalari */}
        <div className="flex gap-2 border-b border-slate-800 pb-3">
          <button
            onClick={() => setSelectedHall('h1')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition ${
              selectedHall === 'h1'
                ? 'bg-slate-800 text-white border border-slate-700'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            🏛️ Asosiy zal (12 stol)
          </button>
          <button
            onClick={() => setSelectedHall('h2')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition ${
              selectedHall === 'h2'
                ? 'bg-slate-800 text-white border border-slate-700'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            🌿 Yozgi ayvon (8 stol)
          </button>
        </div>

        {/* 2D Xarita (Floor plan canvas) */}
        <div className="flex-1 bg-slate-900/80 rounded-2xl border border-slate-800 relative min-h-[500px] overflow-hidden p-6">
          {/* Koordinata to'ri fon sifatida */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:40px_40px] opacity-30 pointer-events-none" />

          {activeHallTables.map((table) => {
            const isRound = table.shape === 'round';
            const isSelected = selectedTable?.id === table.id;

            return (
              <div
                key={table.id}
                onClick={() => setSelectedTable(table)}
                style={{
                  left: `${table.posX}px`,
                  top: `${table.posY}px`,
                  width: '110px',
                  height: '110px',
                }}
                className={`absolute cursor-pointer border-2 transition p-3 flex flex-col justify-between items-center ${getStatusBorder(
                  table.status
                )} ${isRound ? 'rounded-full' : 'rounded-2xl'} ${
                  isSelected ? 'ring-4 ring-orange-500/50 scale-105' : ''
                }`}
              >
                <div className="text-center">
                  <p className="font-bold text-white text-base">Stol {table.number}</p>
                  <p className="text-[11px] text-slate-400">{table.seats} o&apos;rindiq</p>
                </div>

                {table.currentAmount ? (
                  <span className="text-[11px] font-bold text-white px-2 py-0.5 rounded bg-black/40">
                    {table.currentAmount.toLocaleString()} so&apos;m
                  </span>
                ) : (
                  getStatusBadge(table.status)
                )}
              </div>
            );
          })}
        </div>

        {/* Stol tafsilotlari paneli */}
        {selectedTable && (
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-6">
              <div>
                <span className="text-xs text-slate-400">Tanlangan:</span>
                <p className="text-lg font-bold text-white">Stol {selectedTable.number}</p>
              </div>
              <div>
                <span className="text-xs text-slate-400">O&apos;rindiqlar:</span>
                <p className="text-sm font-semibold text-white">{selectedTable.seats} kishilik</p>
              </div>
              <div>
                <span className="text-xs text-slate-400">Holat:</span>
                <p>{getStatusBadge(selectedTable.status)}</p>
              </div>
              {selectedTable.currentAmount && (
                <div>
                  <span className="text-xs text-slate-400">Joriy hisob:</span>
                  <p className="text-sm font-bold text-emerald-400">{selectedTable.currentAmount.toLocaleString()} so&apos;m</p>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <button className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs font-semibold text-white hover:bg-slate-700">
                Bron qilish
              </button>
              <button className="px-3 py-1.5 rounded-lg bg-orange-500 text-xs font-semibold text-white hover:bg-orange-600">
                Buyurtmani ochish
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

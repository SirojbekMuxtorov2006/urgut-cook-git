import 'package:flutter/material.dart';

class ShiftManagementDialog extends StatefulWidget {
  final bool isShiftOpen;
  final String? shiftNumber;
  final double expectedCash;
  final double totalSales;
  final Function(double startingCash) onOpenShift;
  final Function(double actualCash) onCloseShift;
  final Function(String opType, double amount, String reason) onCashOp;

  const ShiftManagementDialog({
    super.key,
    required this.isShiftOpen,
    this.shiftNumber,
    this.expectedCash = 0,
    this.totalSales = 0,
    required this.onOpenShift,
    required this.onCloseShift,
    required this.onCashOp,
  });

  @override
  State<ShiftManagementDialog> createState() => _ShiftManagementDialogState();
}

class _ShiftManagementDialogState extends State<ShiftManagementDialog> {
  final TextEditingController _cashController = TextEditingController();
  final TextEditingController _reasonController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1E293B),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Container(
        width: 520,
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.point_of_sale, color: Color(0xFFF97316), size: 28),
                    const SizedBox(width: 10),
                    Text(
                      widget.isShiftOpen ? 'Smena Boshqaruvi (${widget.shiftNumber})' : 'Yangi Smena Ochish',
                      style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white70),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const Divider(color: Color(0xFF334155), height: 32),

            if (!widget.isShiftOpen) ...[
              // Smena ochilmagan: Boshlang'ich kassa qoldig'ini kiritish
              const Text(
                'Kassadagi boshlang\'ich naqd pul (mayda pullar):',
                style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _cashController,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white, fontSize: 18),
                decoration: InputDecoration(
                  hintText: 'Masalan: 300 000',
                  hintStyle: const TextStyle(color: Color(0xFF64748B)),
                  suffixText: 'so\'m',
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF97316),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: () {
                    final amount = double.tryParse(_cashController.text) ?? 0.0;
                    widget.onOpenShift(amount);
                    Navigator.pop(context);
                  },
                  child: const Text('Smenani ochish', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
            ] else ...[
              // Smena ochiq: Joriy tushum, X-Hisobot, Inkassatsiya va Smenani yopish
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F172A),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFF334155)),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Jami savdo tushumi:', style: TextStyle(color: Color(0xFF94A3B8))),
                        Text(
                          '${widget.totalSales.toStringAsFixed(0)} so\'m',
                          style: const TextStyle(color: Color(0xFF22C55E), fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Kassadagi kutilayotgan naqd pul:', style: TextStyle(color: Color(0xFF94A3B8))),
                        Text(
                          '${widget.expectedCash.toStringAsFixed(0)} so\'m',
                          style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Color(0xFF475569)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      icon: const Icon(Icons.print, size: 18),
                      label: const Text('X-Hisobot chop etish'),
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('X-Hisobot chop etildi!'), backgroundColor: Colors.blue),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.orange,
                        side: const BorderSide(color: Colors.orange),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      icon: const Icon(Icons.account_balance_wallet, size: 18),
                      label: const Text('Inkassatsiya'),
                      onPressed: () => _showCashOpDialog(context),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Smenani yopish bo'limi (Z-Hisobot)
              const Text(
                'Smenani yopish uchun haqiqiy naqd pulni sanab kiriting:',
                style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _cashController,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white, fontSize: 18),
                decoration: InputDecoration(
                  hintText: 'Kassadagi sanalgan naqd pul',
                  hintStyle: const TextStyle(color: Color(0xFF64748B)),
                  suffixText: 'so\'m',
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFEF4444),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  icon: const Icon(Icons.lock, size: 20),
                  label: const Text('Smenani yopish & Z-Hisobot', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  onPressed: () {
                    final actual = double.tryParse(_cashController.text) ?? 0.0;
                    widget.onCloseShift(actual);
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showCashOpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        title: const Text('Kassa amaliyoti (Inkassatsiya)', style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _cashController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(labelText: 'Summa', labelStyle: TextStyle(color: Color(0xFF94A3B8))),
            ),
            TextField(
              controller: _reasonController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(labelText: 'Sababi', labelStyle: TextStyle(color: Color(0xFF94A3B8))),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Bekor qilish')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF97316)),
            onPressed: () {
              final amount = double.tryParse(_cashController.text) ?? 0.0;
              widget.onCashOp('CASH_OUT', amount, _reasonController.text);
              Navigator.pop(ctx);
            },
            child: const Text('Tasdiqlash'),
          ),
        ],
      ),
    );
  }
}

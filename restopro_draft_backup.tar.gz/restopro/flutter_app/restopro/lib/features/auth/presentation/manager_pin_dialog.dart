import 'package:flutter/material.dart';

class ManagerPinDialog extends StatefulWidget {
  final String actionTitle; // Masalan: "Taomni bekor qilish" yoki "Chegirma berish"
  final Function(String pin, String reason) onAuthorized;

  const ManagerPinDialog({
    super.key,
    required this.actionTitle,
    required this.onAuthorized,
  });

  @override
  State<ManagerPinDialog> createState() => _ManagerPinDialogState();
}

class _ManagerPinDialogState extends State<ManagerPinDialog> {
  String _pin = '';
  final TextEditingController _reasonController = TextEditingController();

  void _onDigit(String d) {
    if (_pin.length < 4) {
      setState(() => _pin += d);
      if (_pin.length == 4 && _reasonController.text.isNotEmpty) {
        _submit();
      }
    }
  }

  void _submit() {
    if (_pin.length == 4) {
      widget.onAuthorized(_pin, _reasonController.text.trim());
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1E293B),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Container(
        width: 440,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.shield, color: Colors.redAccent, size: 40),
            const SizedBox(height: 8),
            Text(
              widget.actionTitle,
              style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            const Text(
              'Ushbu amal faqat Menejer/Admin PIN tasdig\'i bilan bajariladi',
              style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _reasonController,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Bekor qilish sababi (masalan: Mijoz rad etdi)...',
                hintStyle: const TextStyle(color: Color(0xFF64748B), fontSize: 13),
                filled: true,
                fillColor: const Color(0xFF0F172A),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 16),

            // PIN doirachalari
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(4, (i) {
                final filled = i < _pin.length;
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: filled ? Colors.redAccent : Colors.transparent,
                    border: Border.all(color: filled ? Colors.redAccent : const Color(0xFF64748B), width: 2),
                  ),
                );
              }),
            ),
            const SizedBox(height: 20),

            // PIN Klaviaturasi
            _buildKeypad(),
          ],
        ),
      ),
    );
  }

  Widget _buildKeypad() {
    final rows = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      ['C', '0', '⌫'],
    ];

    return Column(
      children: rows.map((row) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: row.map((k) {
              return SizedBox(
                width: 64,
                height: 64,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0F172A),
                    foregroundColor: Colors.white,
                    side: const BorderSide(color: Color(0xFF334155)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: () {
                    if (k == 'C') {
                      setState(() => _pin = '');
                    } else if (k == '⌫') {
                      if (_pin.isNotEmpty) setState(() => _pin = _pin.substring(0, _pin.length - 1));
                    } else {
                      _onDigit(k);
                    }
                  },
                  child: Text(k, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                ),
              );
            }).toList(),
          ),
        );
      }).toList(),
    );
  }
}

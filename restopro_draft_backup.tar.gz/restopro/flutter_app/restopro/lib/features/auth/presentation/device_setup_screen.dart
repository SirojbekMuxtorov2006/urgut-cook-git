import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:restopro/core/device_mode.dart';

class DeviceSetupScreen extends StatefulWidget {
  const DeviceSetupScreen({super.key});

  @override
  State<DeviceSetupScreen> createState() => _DeviceSetupScreenState();
}

class _DeviceSetupScreenState extends State<DeviceSetupScreen> {
  DeviceMode _selectedMode = DeviceMode.hub;
  final TextEditingController _deviceNameController =
      TextEditingController(text: 'Asosiy Kassa (Hub)');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Center(
        child: Container(
          width: 600,
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            color: const Color(0xFF1E293B),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: const Color(0xFF334155)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.devices, color: Color(0xFFF97316), size: 36),
                  SizedBox(width: 12),
                  Text(
                    'Qurilma rejimini sozlash',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'Ushbu kompyuter yoki planshet qaysi vazifada ishlatiladi?',
                style: TextStyle(color: Color(0xFF94A3B8)),
              ),
              const SizedBox(height: 24),

              // Rejimlar tanlash kartochkalari
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: DeviceMode.values.map((mode) {
                  final isSelected = mode == _selectedMode;
                  return InkWell(
                    onTap: () {
                      setState(() {
                        _selectedMode = mode;
                        _deviceNameController.text = mode.displayName;
                      });
                    },
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      width: 260,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? const Color(0xFFF97316).withOpacity(0.15)
                            : const Color(0xFF0F172A),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: isSelected
                              ? const Color(0xFFF97316)
                              : const Color(0xFF334155),
                          width: 2,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            _getModeIcon(mode),
                            color: isSelected ? const Color(0xFFF97316) : Colors.white70,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              mode.displayName,
                              style: TextStyle(
                                color: isSelected ? Colors.white : Colors.white70,
                                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 24),
              TextField(
                controller: _deviceNameController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Qurilma nomi',
                  labelStyle: const TextStyle(color: Color(0xFF94A3B8)),
                  filled: true,
                  fillColor: const Color(0xFF0F172A),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF334155)),
                  ),
                ),
              ),

              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF97316),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onPressed: () {
                    context.go('/login');
                  },
                  child: const Text(
                    'Rejimni saqlash va davom etish',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _getModeIcon(DeviceMode mode) {
    switch (mode) {
      case DeviceMode.pos:
        return Icons.point_of_sale;
      case DeviceMode.hub:
        return Icons.hub;
      case DeviceMode.waiter:
        return Icons.phone_android;
      case DeviceMode.kds:
        return Icons.soup_kitchen;
      case DeviceMode.manager:
        return Icons.admin_panel_settings;
      case DeviceMode.courier:
        return Icons.delivery_dining;
    }
  }
}

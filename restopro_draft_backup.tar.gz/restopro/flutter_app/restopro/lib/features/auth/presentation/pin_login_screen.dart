import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:restopro/core/network/api_client.dart';

class PinLoginScreen extends StatefulWidget {
  const PinLoginScreen({super.key});

  @override
  State<PinLoginScreen> createState() => _PinLoginScreenState();
}

class _PinLoginScreenState extends State<PinLoginScreen> {
  String _pin = '';
  bool _isLoading = false;
  String? _errorMessage;
  final ApiClient _apiClient = ApiClient();

  void _onDigitPress(String digit) {
    if (_pin.length < 4) {
      setState(() {
        _pin += digit;
        _errorMessage = null;
      });
      if (_pin.length == 4) {
        _submitPin();
      }
    }
  }

  void _onBackspace() {
    if (_pin.isNotEmpty) {
      setState(() {
        _pin = _pin.substring(0, _pin.length - 1);
        _errorMessage = null;
      });
    }
  }

  void _onClear() {
    setState(() {
      _pin = '';
      _errorMessage = null;
    });
  }

  Future<void> _submitPin() async {
    setState(() => _isLoading = true);
    try {
      final res = await _apiClient.pinLogin(_pin);
      if (mounted) {
        final userName = res.data['user']['full_name'];
        final role = res.data['user']['role'];
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Xush kelibsiz, $userName ($role)!'),
            backgroundColor: Colors.green,
          ),
        );
        context.go('/pos');
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Noto'g'ri PIN-kod! Qaytadan urinib ko'ring.";
        _pin = '';
      });
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Center(
        child: Container(
          width: 440,
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            color: const Color(0xFF1E293B),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: const Color(0xFF334155)),
            boxShadow: const [
              BoxShadow(
                color: Colors.black45,
                blurRadius: 30,
                offset: Offset(0, 10),
              )
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.restaurant, size: 48, color: Color(0xFFF97316)),
              const SizedBox(height: 12),
              const Text(
                'RestoPro POS',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Tizimga kirish uchun 4 xonali PIN-kodni tering',
                style: TextStyle(fontSize: 14, color: Color(0xFF94A3B8)),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),

              // PIN doirachalari
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (index) {
                  final isFilled = index < _pin.length;
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isFilled ? const Color(0xFFF97316) : Colors.transparent,
                      border: Border.all(
                        color: isFilled ? const Color(0xFFF97316) : const Color(0xFF64748B),
                        width: 2,
                      ),
                    ),
                  );
                }),
              ),

              if (_errorMessage != null) ...[
                const SizedBox(height: 16),
                Text(
                  _errorMessage!,
                  style: const TextStyle(color: Colors.redAccent, fontSize: 13),
                  textAlign: TextAlign.center,
                ),
              ],

              const SizedBox(height: 28),

              // Sensorli raqamlar klaviaturasi (kamida 60px tugmalar)
              _buildPinKeypad(),

              const SizedBox(height: 16),
              if (_isLoading)
                const CircularProgressIndicator(color: Color(0xFFF97316)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPinKeypad() {
    final rows = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      ['C', '0', '⌫'],
    ];

    return Column(
      children: rows.map((row) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: row.map((key) {
              return SizedBox(
                width: 72,
                height: 72,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: key == 'C' || key == '⌫'
                        ? const Color(0xFF334155)
                        : const Color(0xFF1E293B),
                    foregroundColor: Colors.white,
                    side: const BorderSide(color: Color(0xFF475569)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 2,
                  ),
                  onPressed: () {
                    if (key == 'C') {
                      _onClear();
                    } else if (key == '⌫') {
                      _onBackspace();
                    } else {
                      _onDigitPress(key);
                    }
                  },
                  child: Text(
                    key,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ),
              );
            }).toList(),
          ),
        );
      }).toList(),
    );
  }
}

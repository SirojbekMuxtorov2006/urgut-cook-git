import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class PosMainScreen extends StatefulWidget {
  const PosMainScreen({super.key});

  @override
  State<PosMainScreen> createState() => _PosMainScreenState();
}

class _PosMainScreenState extends State<PosMainScreen> {
  int _selectedTabIndex = 0; // 0: Stollar, 1: Tezkor sotuv
  String? _selectedTable = "1";
  final List<Map<String, dynamic>> _cartItems = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Column(
        children: [
          // 1. Yuqori status satri (Restoran, kassir, internet status, vaqt)
          _buildTopBar(),

          // 2. Asosiy ishchi maydon
          Expanded(
            child: Row(
              children: [
                // Chap qism: Stollar xaritasi yoki Taomlar katalogi
                Expanded(
                  flex: 7,
                  child: _selectedTabIndex == 0
                      ? _buildTablesGrid()
                      : _buildMenuCatalog(),
                ),

                // O'ng qism: Savat va hisob-kitob (POS Terminal savati)
                Container(
                  width: 420,
                  decoration: const BoxDecoration(
                    color: Color(0xFF1E293B),
                    border: Border(
                      left: BorderSide(color: Color(0xFF334155)),
                    ),
                  ),
                  child: _buildCartPanel(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      height: 64,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: const BoxDecoration(
        color: Color(0xFF1E293B),
        border: Border(bottom: BorderSide(color: Color(0xFF334155))),
      ),
      child: Row(
        children: [
          const Icon(Icons.restaurant, color: Color(0xFFF97316), size: 28),
          const SizedBox(width: 10),
          const Text(
            'Chorsu Milliy Taomlar',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(width: 32),

          // Rejim tugmalari
          _buildTabButton('Stollar xaritasi', 0, Icons.table_bar),
          const SizedBox(width: 8),
          _buildTabButton('Tezkor sotuv', 1, Icons.flash_on),

          const Spacer(),

          // Status indikatori
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.green),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.circle, color: Colors.green, size: 10),
                SizedBox(width: 6),
                Text('🟢 Online · Hub: 8787', style: TextStyle(color: Colors.green, fontSize: 13, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          const SizedBox(width: 16),

          // Kassir ma'lumoti va chiqish
          const Row(
            children: [
              Icon(Icons.account_circle, color: Colors.white70),
              SizedBox(width: 6),
              Text('Dilshod (Kassir 1)', style: TextStyle(color: Colors.white)),
            ],
          ),
          const SizedBox(width: 12),
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.redAccent),
            tooltip: 'Chiqish',
            onPressed: () => context.go('/login'),
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(String label, int index, IconData icon) {
    final isSelected = _selectedTabIndex == index;
    return ElevatedButton.icon(
      style: ElevatedButton.styleFrom(
        backgroundColor: isSelected ? const Color(0xFFF97316) : const Color(0xFF0F172A),
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 0,
      ),
      onPressed: () => setState(() => _selectedTabIndex = index),
      icon: Icon(icon, size: 18),
      label: Text(label),
    );
  }

  Widget _buildTablesGrid() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Asosiy zal (12 stol) · Yozgi ayvon (8 stol)',
            style: TextStyle(color: Color(0xFF94A3B8), fontSize: 16, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 5,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 1.2,
              ),
              itemCount: 20,
              itemBuilder: (context, index) {
                final tableNumber = '${index + 1}';
                final isSelected = _selectedTable == tableNumber;
                final isOccupied = index % 3 == 0; // Demo band stollar

                return InkWell(
                  onTap: () {
                    setState(() {
                      _selectedTable = tableNumber;
                      _selectedTabIndex = 1; // Stol bosilganda taomlar menyusiga o'tadi
                    });
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    decoration: BoxDecoration(
                      color: isOccupied ? const Color(0xFFEF4444).withOpacity(0.2) : const Color(0xFF22C55E).withOpacity(0.15),
                      border: Border.all(
                        color: isSelected
                            ? const Color(0xFFF97316)
                            : (isOccupied ? Colors.redAccent : Colors.green),
                        width: isSelected ? 3 : 1.5,
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Stol $tableNumber',
                          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          isOccupied ? '🔴 Band (124 000 so\'m)' : '🟢 Bo\'sh (4 kishi)',
                          style: TextStyle(
                            color: isOccupied ? Colors.redAccent : Colors.green,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuCatalog() {
    final categories = ['Hammasi', 'Birinchi', 'Osh va Ikkinchi', 'Kavob', 'Somsa', 'Salat', 'Ichimlik'];
    final sampleDishes = [
      {'name': 'To\'y Oshi', 'price': 38000, 'cat': 'Osh va Ikkinchi'},
      {'name': 'Sho\'rva (Qo\'y)', 'price': 42000, 'cat': 'Birinchi'},
      {'name': 'Qozon Kabob', 'price': 65000, 'cat': 'Osh va Ikkinchi'},
      {'name': 'Qiyma Shashlik', 'price': 22000, 'cat': 'Kavob'},
      {'name': 'Kuskovoy Shashlik', 'price': 26000, 'cat': 'Kavob'},
      {'name': 'Tandir Somsa', 'price': 14000, 'cat': 'Somsa'},
      {'name': 'Achchiq-chuchuk', 'price': 15000, 'cat': 'Salat'},
      {'name': 'Ko\'k Choy (choynak)', 'price': 6000, 'cat': 'Ichimlik'},
    ];

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Kategoriyalar satri
          SizedBox(
            height: 48,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                return Chip(
                  backgroundColor: i == 0 ? const Color(0xFFF97316) : const Color(0xFF1E293B),
                  label: Text(
                    categories[i],
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 16),

          // Taomlar plitkasi
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.1,
              ),
              itemCount: sampleDishes.length,
              itemBuilder: (context, i) {
                final dish = sampleDishes[i];
                return InkWell(
                  onTap: () {
                    setState(() {
                      _cartItems.add({
                        'name': dish['name'],
                        'price': dish['price'],
                        'qty': 1,
                      });
                    });
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E293B),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF334155)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          dish['name'] as String,
                          style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                          maxLines: 2,
                        ),
                        const Spacer(),
                        Text(
                          '${dish['price']} so\'m',
                          style: const TextStyle(color: Color(0xFFF97316), fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCartPanel() {
    double subtotal = 0;
    for (final item in _cartItems) {
      subtotal += (item['price'] as int) * (item['qty'] as int);
    }
    final serviceFee = subtotal * 0.10;
    final total = subtotal + serviceFee;

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Buyurtma: Stol ${_selectedTable ?? "Tanlanmagan"}',
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                onPressed: () => setState(() => _cartItems.clear()),
              ),
            ],
          ),
          const Divider(color: Color(0xFF334155)),

          // Savat elementlari
          Expanded(
            child: _cartItems.isEmpty
                ? const Center(
                    child: Text('Savat bo\'sh. Taomlarni tanlang.', style: TextStyle(color: Color(0xFF64748B))),
                  )
                : ListView.builder(
                    itemCount: _cartItems.length,
                    itemBuilder: (context, i) {
                      final item = _cartItems[i];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0F172A),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(item['name'], style: const TextStyle(color: Colors.white)),
                            ),
                            Text('${item['price']} so\'m', style: const TextStyle(color: Color(0xFFF97316))),
                          ],
                        ),
                      );
                    },
                  ),
          ),

          const Divider(color: Color(0xFF334155)),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Jami:', style: TextStyle(color: Color(0xFF94A3B8))),
              Text('${subtotal.toStringAsFixed(0)} so\'m', style: const TextStyle(color: Colors.white)),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Xizmat haqi (10%):', style: TextStyle(color: Color(0xFF94A3B8))),
              Text('${serviceFee.toStringAsFixed(0)} so\'m', style: const TextStyle(color: Colors.white)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('TO\'LOVGA:', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              Text(
                '${total.toStringAsFixed(0)} so\'m',
                style: const TextStyle(color: Color(0xFF22C55E), fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Tezkor tugmalar (Oshxonaga yuborish / To'lov)
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 54,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFFF97316),
                      side: const BorderSide(color: Color(0xFFF97316)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Chipta sex printerlariga va KDS ga yuborildi!'), backgroundColor: Colors.orange),
                      );
                    },
                    child: const Text('Oshxonaga (F1)', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: SizedBox(
                  height: 54,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF22C55E),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('To\'lov qabul qilindi va chek chop etildi!'), backgroundColor: Colors.green),
                      );
                      setState(() => _cartItems.clear());
                    },
                    child: const Text('To\'lov (F5)', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

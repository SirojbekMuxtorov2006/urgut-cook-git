import 'package:flutter/material.dart';

class DishModifierDialog extends StatefulWidget {
  final String dishName;
  final double basePrice;
  final List<Map<String, dynamic>> variants;
  final List<Map<String, dynamic>> modifiers;
  final Function(Map<String, dynamic> selectedOrder) onConfirm;

  const DishModifierDialog({
    super.key,
    required this.dishName,
    required this.basePrice,
    required this.variants,
    required this.modifiers,
    required this.onConfirm,
  });

  @override
  State<DishModifierDialog> createState() => _DishModifierDialogState();
}

class _DishModifierDialogState extends State<DishModifierDialog> {
  int _quantity = 1;
  late Map<String, dynamic> _selectedVariant;
  final Set<String> _selectedModifierIds = {};
  final TextEditingController _commentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.variants.isNotEmpty) {
      _selectedVariant = widget.variants.firstWhere(
        (v) => v['is_default'] == true,
        orElse: () => widget.variants.first,
      );
    } else {
      _selectedVariant = {'name': 'Standart', 'price': widget.basePrice};
    }
  }

  double get _unitPrice {
    double price = (_selectedVariant['price'] as num).toDouble();
    for (final mod in widget.modifiers) {
      if (_selectedModifierIds.contains(mod['id'])) {
        price += (mod['price'] as num).toDouble();
      }
    }
    return price;
  }

  double get _totalPrice => _unitPrice * _quantity;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1E293B),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Container(
        width: 520,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    widget.dishName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white70),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // 1. Variantlar (masalan: 0.5 pors, 1 pors, 1 kg)
            if (widget.variants.isNotEmpty) ...[
              const Text(
                'Variantni tanlang:',
                style: TextStyle(color: Color(0xFF94A3B8), fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: widget.variants.map((v) {
                  final isSelected = _selectedVariant['name'] == v['name'];
                  return ChoiceChip(
                    label: Text('${v['name']} (${v['price']} so\'m)'),
                    selected: isSelected,
                    selectedColor: const Color(0xFFF97316),
                    backgroundColor: const Color(0xFF0F172A),
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : Colors.white70,
                      fontWeight: FontWeight.bold,
                    ),
                    onSelected: (val) {
                      if (val) setState(() => _selectedVariant = v);
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
            ],

            // 2. Modifikatorlar (masalan: +Qazi, +Bedana tuxumi)
            if (widget.modifiers.isNotEmpty) ...[
              const Text(
                'Qo\'shimchalar (Modifierlar):',
                style: TextStyle(color: Color(0xFF94A3B8), fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: widget.modifiers.map((mod) {
                  final isChecked = _selectedModifierIds.contains(mod['id']);
                  return FilterChip(
                    label: Text('${mod['name']} (+${mod['price']} so\'m)'),
                    selected: isChecked,
                    selectedColor: const Color(0xFFF97316).withOpacity(0.3),
                    checkmarkColor: const Color(0xFFF97316),
                    backgroundColor: const Color(0xFF0F172A),
                    side: BorderSide(
                      color: isChecked ? const Color(0xFFF97316) : const Color(0xFF334155),
                    ),
                    labelStyle: TextStyle(
                      color: isChecked ? Colors.white : Colors.white70,
                    ),
                    onSelected: (selected) {
                      setState(() {
                        if (selected) {
                          _selectedModifierIds.add(mod['id']);
                        } else {
                          _selectedModifierIds.remove(mod['id']);
                        }
                      });
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
            ],

            // 3. Oshpaz uchun maxsus izoh
            TextField(
              controller: _commentController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Oshpaz uchun izoh (masalan: Piyozsiz, beztuz)...',
                hintStyle: const TextStyle(color: Color(0xFF64748B), fontSize: 13),
                filled: true,
                fillColor: const Color(0xFF0F172A),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF334155)),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // 4. Soni (Quantity) va Jami narx
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    _buildQtyBtn(Icons.remove, () {
                      if (_quantity > 1) setState(() => _quantity--);
                    }),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        '$_quantity',
                        style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ),
                    _buildQtyBtn(Icons.add, () => setState(() => _quantity++)),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('Jami summa:', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12)),
                    Text(
                      '${_totalPrice.toStringAsFixed(0)} so\'m',
                      style: const TextStyle(
                        color: Color(0xFF22C55E),
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Tasdiqlash tugmasi
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF97316),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: () {
                  widget.onConfirm({
                    'dishName': widget.dishName,
                    'variant': _selectedVariant,
                    'selectedModifierIds': _selectedModifierIds.toList(),
                    'comment': _commentController.text.trim(),
                    'quantity': _quantity,
                    'unitPrice': _unitPrice,
                    'totalPrice': _totalPrice,
                  });
                  Navigator.pop(context);
                },
                child: const Text('Savatga qo\'shish', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQtyBtn(IconData icon, VoidCallback onTap) {
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: IconButton(
        icon: Icon(icon, color: Colors.white, size: 20),
        onPressed: onTap,
      ),
    );
  }
}

import 'package:flutter/material.dart';

class StopListManagerScreen extends StatefulWidget {
  const StopListManagerScreen({super.key});

  @override
  State<StopListManagerScreen> createState() => _StopListManagerScreenState();
}

class _StopListManagerScreenState extends State<StopListManagerScreen> {
  String _searchQuery = '';
  final List<Map<String, dynamic>> _dishes = [
    {'id': '1', 'name': 'To\'y Oshi', 'category': 'Osh va Ikkinchi', 'isAvailable': true, 'price': 38000},
    {'id': '2', 'name': 'Sho\'rva (Qo\'y go\'shtli)', 'category': 'Birinchi', 'isAvailable': true, 'price': 42000},
    {'id': '3', 'name': 'Qozon Kabob', 'category': 'Osh va Ikkinchi', 'isAvailable': false, 'price': 65000, 'reason': 'Go\'sht tugadi'},
    {'id': '4', 'name': 'Qiyma Shashlik', 'category': 'Kavob', 'isAvailable': true, 'price': 22000},
    {'id': '5', 'name': 'Tandir Somsa', 'category': 'Somsa', 'isAvailable': false, 'price': 14000, 'reason': 'Bugungi partiya tugadi'},
    {'id': '6', 'name': 'Manti (Go\'shtli)', 'category': 'Osh va Ikkinchi', 'isAvailable': true, 'price': 42000},
    {'id': '7', 'name': 'Norin', 'category': 'Osh va Ikkinchi', 'isAvailable': true, 'price': 45000},
    {'id': '8', 'name': 'Achchiq-chuchuk', 'category': 'Salat', 'isAvailable': true, 'price': 15000},
  ];

  @override
  Widget build(BuildContext context) {
    final filtered = _dishes.where((d) {
      final name = d['name'].toString().toLowerCase();
      return name.contains(_searchQuery.toLowerCase());
    }).toList();

    final stoppedCount = _dishes.where((d) => d['isAvailable'] == false).length;

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        title: Text('Stop-list Boshqaruvi ($stoppedCount ta taom to\'xtatilgan)'),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Qidiruv maydoni
            TextField(
              onChanged: (val) => setState(() => _searchQuery = val),
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Taom nomini qidiring...',
                hintStyle: const TextStyle(color: Color(0xFF64748B)),
                prefixIcon: const Icon(Icons.search, color: Color(0xFF94A3B8)),
                filled: true,
                fillColor: const Color(0xFF1E293B),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: Color(0xFF334155)),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Taomlar ro'yxati
            Expanded(
              child: ListView.separated(
                itemCount: filtered.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, i) {
                  final dish = filtered[i];
                  final isAvailable = dish['isAvailable'] as bool;

                  return Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E293B),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isAvailable ? const Color(0xFF334155) : Colors.redAccent.withOpacity(0.5),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: isAvailable ? Colors.green.withOpacity(0.15) : Colors.red.withOpacity(0.15),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            isAvailable ? Icons.check_circle_outline : Icons.block,
                            color: isAvailable ? Colors.green : Colors.redAccent,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                dish['name'],
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  decoration: isAvailable ? null : TextDecoration.lineThrough,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${dish['category']} · ${dish['price']} so\'m',
                                style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
                              ),
                              if (!isAvailable && dish['reason'] != null) ...[
                                const SizedBox(height: 2),
                                Text(
                                  'Sabab: ${dish['reason']}',
                                  style: const TextStyle(color: Colors.redAccent, fontSize: 12),
                                ),
                              ],
                            ],
                          ),
                        ),
                        // Stop-listga kiritish / chiqarish Switch tugmasi
                        Switch(
                          value: isAvailable,
                          activeColor: Colors.green,
                          inactiveThumbColor: Colors.redAccent,
                          inactiveTrackColor: Colors.redAccent.withOpacity(0.3),
                          onChanged: (val) {
                            setState(() {
                              dish['isAvailable'] = val;
                              if (!val) {
                                dish['reason'] = 'Mahsulot tugadi';
                              }
                            });
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  val
                                      ? '${dish['name']} sotuvga qaytarildi!'
                                      : '${dish['name']} stop-listga kiritildi (barcha kassa va QR menyudan yashirildi)!',
                                ),
                                backgroundColor: val ? Colors.green : Colors.redAccent,
                                duration: const Duration(seconds: 2),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

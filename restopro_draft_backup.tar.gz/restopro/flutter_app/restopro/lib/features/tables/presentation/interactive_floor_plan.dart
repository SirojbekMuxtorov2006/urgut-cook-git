import 'package:flutter/material.dart';

enum TableStatusType {
  vacant,        // Bo'sh 🟢
  occupied,      // Band 🔴
  billRequested, // Hisob so'ralgan 🟡
  reserved;      // Bron qilingan 🔵

  Color get color {
    switch (this) {
      case TableStatusType.vacant:
        return const Color(0xFF22C55E); // Yashil
      case TableStatusType.occupied:
        return const Color(0xFFEF4444); // Qizil
      case TableStatusType.billRequested:
        return const Color(0xFFEAB308); // Sariq
      case TableStatusType.reserved:
        return const Color(0xFF3B82F6); // Ko'k
    }
  }

  String get label {
    switch (this) {
      case TableStatusType.vacant:
        return "Bo'sh";
      case TableStatusType.occupied:
        return 'Band';
      case TableStatusType.billRequested:
        return 'Hisob so\'raldi';
      case TableStatusType.reserved:
        return 'Bron';
    }
  }
}

class TableItemModel {
  final String id;
  final String number;
  final int seats;
  final TableStatusType status;
  final double posX;
  final double posY;
  final double width;
  final double height;
  final String shape;
  final double? currentTotal;
  final String? waiterName;
  final String? occupiedDuration;

  TableItemModel({
    required this.id,
    required this.number,
    required this.seats,
    required this.status,
    required this.posX,
    required this.posY,
    this.width = 110,
    this.height = 110,
    this.shape = 'rectangle',
    this.currentTotal,
    this.waiterName,
    this.occupiedDuration,
  });
}

class InteractiveFloorPlan extends StatefulWidget {
  final List<TableItemModel> tables;
  final String? selectedTableId;
  final ValueChanged<TableItemModel> onTableSelected;
  final bool isEditMode;
  final Function(String id, double x, double y)? onTableMoved;

  const InteractiveFloorPlan({
    super.key,
    required this.tables,
    this.selectedTableId,
    required this.onTableSelected,
    this.isEditMode = false,
    this.onTableMoved,
  });

  @override
  State<InteractiveFloorPlan> createState() => _InteractiveFloorPlanState();
}

class _InteractiveFloorPlanState extends State<InteractiveFloorPlan> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: Stack(
        children: [
          // Grid chiziqlari (Fondagi koordinata to'ri)
          CustomPaint(
            size: Size.infinite,
            painter: _GridBackgroundPainter(),
          ),

          // Stollar
          ...widget.tables.map((table) {
            final isSelected = widget.selectedTableId == table.id;

            return Positioned(
              left: table.posX,
              top: table.posY,
              child: widget.isEditMode
                  ? Draggable(
                      feedback: _buildTableWidget(table, isSelected, isDragging: true),
                      childWhenDragging: Opacity(
                        opacity: 0.3,
                        child: _buildTableWidget(table, isSelected),
                      ),
                      onDragEnd: (details) {
                        final renderBox = context.findRenderObject() as RenderBox?;
                        if (renderBox != null) {
                          final localPos = renderBox.globalToLocal(details.offset);
                          widget.onTableMoved?.call(table.id, localPos.dx, localPos.dy);
                        }
                      },
                      child: _buildTableWidget(table, isSelected),
                    )
                  : InkWell(
                      onTap: () => widget.onTableSelected(table),
                      borderRadius: BorderRadius.circular(table.shape == 'round' ? 60 : 16),
                      child: _buildTableWidget(table, isSelected),
                    ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildTableWidget(TableItemModel table, bool isSelected, {bool isDragging = false}) {
    final statusColor = table.status.color;
    final isRound = table.shape == 'round';

    return Container(
      width: table.width,
      height: table.height,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.18),
        shape: isRound ? BoxShape.circle : BoxShape.rectangle,
        borderRadius: isRound ? null : BorderRadius.circular(16),
        border: Border.all(
          color: isSelected ? const Color(0xFFF97316) : statusColor,
          width: isSelected ? 3.5 : 2.0,
        ),
        boxShadow: [
          if (isSelected || isDragging)
            BoxShadow(
              color: (isSelected ? const Color(0xFFF97316) : statusColor).withOpacity(0.4),
              blurRadius: 16,
              spreadRadius: 2,
            ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Stol ${table.number}',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            '${table.seats} o\'rindiq',
            style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 11),
          ),
          if (table.currentTotal != null && table.currentTotal! > 0) ...[
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.3),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                '${table.currentTotal!.toStringAsFixed(0)} so\'m',
                style: TextStyle(
                  color: statusColor,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _GridBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1E293B).withOpacity(0.5)
      ..strokeWidth = 1.0;

    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

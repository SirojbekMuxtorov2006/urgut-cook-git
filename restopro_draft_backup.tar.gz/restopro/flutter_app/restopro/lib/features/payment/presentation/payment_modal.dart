import 'package:flutter/material.dart';

class PaymentModal extends StatefulWidget {
  final String orderNumber;
  final String tableNumber;
  final double totalAmount;
  final Function(String method, double tendered, double change) onPaymentSuccess;

  const PaymentModal({
    super.key,
    required this.orderNumber,
    required this.tableNumber,
    required this.totalAmount,
    required this.onPaymentSuccess,
  });

  @override
  State<PaymentModal> createState() => _PaymentModalState();
}

class _PaymentModalState extends State<PaymentModal> {
  String _selectedMethod = 'CASH'; // CASH, UZCARD, HUMO, CLICK, PAYME, DEBT
  double _tenderedAmount = 0;
  final TextEditingController _cashInputController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tenderedAmount = widget.totalAmount;
    _cashInputController.text = widget.totalAmount.toStringAsFixed(0);
  }

  double get _changeAmount {
    if (_selectedMethod != 'CASH') return 0.0;
    final diff = _tenderedAmount - widget.totalAmount;
    return diff > 0 ? diff : 0.0;
  }

  void _setQuickCash(double amount) {
    setState(() {
      _tenderedAmount = amount;
      _cashInputController.text = amount.toStringAsFixed(0);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1E293B),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Container(
        width: 640,
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Sarlavha
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'To\'lov qabul qilish: ${widget.tableNumber}',
                      style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'Chek №: ${widget.orderNumber}',
                      style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
                    ),
                  ],
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white70),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // To'lov usullari tugmalari
            const Text(
              'To\'lov usulini tanlang:',
              style: TextStyle(color: Color(0xFF94A3B8), fontWeight: FontWeight.bold, fontSize: 13),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                _buildMethodCard('Naqd pul', 'CASH', Icons.payments, Colors.green),
                const SizedBox(width: 8),
                _buildMethodCard('Uzcard/Humo', 'UZCARD', Icons.credit_card, Colors.blue),
                const SizedBox(width: 8),
                _buildMethodCard('Click / Payme', 'CLICK', Icons.phone_android, Colors.cyan),
                const SizedBox(width: 8),
                _buildMethodCard('Nasiya (Qarz)', 'DEBT', Icons.menu_book, Colors.orange),
              ],
            ),
            const SizedBox(height: 24),

            // Jami summa
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF0F172A),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF334155)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('To\'lov summasi:', style: TextStyle(color: Colors.white70, fontSize: 16)),
                  Text(
                    '${widget.totalAmount.toStringAsFixed(0)} so\'m',
                    style: const TextStyle(color: Color(0xFF22C55E), fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Naqd to'lov bo'lsa: Qabul qilingan summa va Qaytim
            if (_selectedMethod == 'CASH') ...[
              const Text(
                'Mijoz bergan naqd pul:',
                style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _cashInputController,
                      keyboardType: TextInputType.number,
                      style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: const Color(0xFF0F172A),
                        suffixText: 'so\'m',
                        suffixStyle: const TextStyle(color: Color(0xFF94A3B8)),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Color(0xFF334155)),
                        ),
                      ),
                      onChanged: (val) {
                        final parsed = double.tryParse(val) ?? 0.0;
                        setState(() => _tenderedAmount = parsed);
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              // Tezkor kupyuralar
              Wrap(
                spacing: 8,
                children: [
                  _buildQuickCashChip('Aniq summa', widget.totalAmount),
                  _buildQuickCashChip('50 000', 50000),
                  _buildQuickCashChip('100 000', 100000),
                  _buildQuickCashChip('200 000', 200000),
                  _buildQuickCashChip('500 000', 500000),
                ],
              ),
              const SizedBox(height: 16),

              // Qaytim
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: _changeAmount > 0 ? Colors.orange.withOpacity(0.15) : const Color(0xFF0F172A),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _changeAmount > 0 ? Colors.orange : const Color(0xFF334155),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Mijozga qaytim:', style: TextStyle(color: Colors.white70, fontSize: 15)),
                    Text(
                      '${_changeAmount.toStringAsFixed(0)} so\'m',
                      style: TextStyle(
                        color: _changeAmount > 0 ? Colors.orange : Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
            ],

            // To'lovni tasdiqlash va chek chiqarish tugmasi
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF22C55E),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 4,
                ),
                icon: const Icon(Icons.print, size: 22),
                label: const Text(
                  'To\'lovni qabul qilish & Chek chop etish (F5)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                onPressed: () {
                  if (_selectedMethod == 'CASH' && _tenderedAmount < widget.totalAmount) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Mijoz bergan pul kam!'), backgroundColor: Colors.redAccent),
                    );
                    return;
                  }
                  widget.onPaymentSuccess(_selectedMethod, _tenderedAmount, _changeAmount);
                  Navigator.pop(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMethodCard(String title, String method, IconData icon, Color color) {
    final isSelected = _selectedMethod == method;
    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() {
            _selectedMethod = method;
            if (method != 'CASH') {
              _tenderedAmount = widget.totalAmount;
              _cashInputController.text = widget.totalAmount.toStringAsFixed(0);
            }
          });
        },
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: isSelected ? color.withOpacity(0.2) : const Color(0xFF0F172A),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isSelected ? color : const Color(0xFF334155),
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Column(
            children: [
              Icon(icon, color: isSelected ? color : Colors.white70, size: 24),
              const SizedBox(height: 6),
              Text(
                title,
                style: TextStyle(
                  color: isSelected ? Colors.white : Colors.white70,
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickCashChip(String label, double amount) {
    return ActionChip(
      label: Text(label),
      backgroundColor: const Color(0xFF0F172A),
      side: const BorderSide(color: Color(0xFF475569)),
      labelStyle: const TextStyle(color: Colors.white, fontSize: 12),
      onPressed: () => _setQuickCash(amount),
    );
  }
}

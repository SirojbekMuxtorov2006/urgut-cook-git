enum DeviceMode {
  pos,       // Kassa (POS terminal)
  hub,       // Asosiy kassa = Lokal Hub (shelf HTTP server)
  waiter,    // Ofitsiant ilovasi (mobil telefon)
  kds,       // Oshxona ekrani (planshet/TV)
  manager,   // Boshqaruv / Ega ilovasi
  courier;   // Kuryer yetkazish rejimi

  String get displayName {
    switch (this) {
      case DeviceMode.pos:
        return 'Kassa (POS)';
      case DeviceMode.hub:
        return 'Asosiy Kassa (Lokal Hub)';
      case DeviceMode.waiter:
        return 'Ofitsiant ilovasi';
      case DeviceMode.kds:
        return 'Oshxona ekrani (KDS)';
      case DeviceMode.manager:
        return 'Boshqaruv (Menejer)';
      case DeviceMode.courier:
        return 'Kuryer rejimi';
    }
  }
}

import 'dart:io';
import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

part 'app_database.g.dart';

// 1. Kategoriyalar
class LocalCategories extends Table {
  TextColumn get id => text()();
  TextColumn get nameUz => text()();
  TextColumn get nameRu => text().nullable()();
  TextColumn get icon => text().withDefault(const Constant('utensils'))();
  TextColumn get color => text().withDefault(const Constant('#f97316'))();
  IntColumn get sortOrder => integer().withDefault(const Constant(1))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();

  @override
  Set<Column> get primaryKey => {id};
}

// 2. Taomlar
class LocalMenuItems extends Table {
  TextColumn get id => text()();
  TextColumn get categoryId => text()();
  TextColumn get nameUz => text()();
  TextColumn get nameRu => text().nullable()();
  RealColumn get price => real()();
  RealColumn get costPrice => real().withDefault(const Constant(0.0))();
  TextColumn get unit => text().withDefault(const Constant('PORTION'))();
  TextColumn get stationId => text().nullable()();
  BoolColumn get isAvailable => boolean().withDefault(const Constant(true))();

  @override
  Set<Column> get primaryKey => {id};
}

// 3. Stollar
class LocalTables extends Table {
  TextColumn get id => text()();
  TextColumn get hallName => text()();
  TextColumn get number => text()();
  IntColumn get seats => integer().withDefault(const Constant(4))();
  TextColumn get status => text().withDefault(const Constant('VACANT'))();
  RealColumn get posX => real().withDefault(const Constant(0.0))();
  RealColumn get posY => real().withDefault(const Constant(0.0))();

  @override
  Set<Column> get primaryKey => {id};
}

// 4. Offline Sync Outbox (Kassada to'langan yoki yaratilgan buyurtmalar)
class LocalSyncOutbox extends Table {
  TextColumn get id => text()();
  TextColumn get entityName => text()(); // ORDER, PAYMENT, SHIFT
  TextColumn get action => text()();     // CREATE, UPDATE, DELETE
  TextColumn get payloadJson => text()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  IntColumn get retryCount => integer().withDefault(const Constant(0))();

  @override
  Set<Column> get primaryKey => {id};
}

@DriftDatabase(tables: [LocalCategories, LocalMenuItems, LocalTables, LocalSyncOutbox])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  @override
  int get schemaVersion => 1;
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dbFolder = await getApplicationDocumentsDirectory();
    final file = File(p.join(dbFolder.path, 'restopro_offline.sqlite'));
    return NativeDatabase.createInBackground(file);
  });
}

import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ApiClient {
  static const String defaultBaseUrl = 'http://127.0.0.1:8000/api/v1';
  final Dio dio;
  final FlutterSecureStorage storage;

  ApiClient({String baseUrl = defaultBaseUrl})
      : storage = const FlutterSecureStorage(),
        dio = Dio(BaseOptions(
          baseUrl: baseUrl,
          connectTimeout: const Duration(seconds: 10),
          receiveTimeout: const Duration(seconds: 10),
          headers: {'Content-Type': 'application/json'},
        )) {
    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await storage.read(key: 'access_token');
          if (token != null) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          final deviceToken = await storage.read(key: 'device_token');
          if (deviceToken != null) {
            options.headers['X-Device-Token'] = deviceToken;
          }
          return handler.next(options);
        },
        onError: (DioException e, handler) async {
          // Token eskirgan bo'lsa refresh qilish
          if (e.response?.statusCode == 401) {
            final refreshToken = await storage.read(key: 'refresh_token');
            if (refreshToken != null) {
              try {
                final refreshRes = await Dio().post(
                  '$baseUrl/auth/refresh/',
                  data: {'refresh': refreshToken},
                );
                final newAccess = refreshRes.data['access'];
                await storage.write(key: 'access_token', value: newAccess);
                e.requestOptions.headers['Authorization'] = 'Bearer $newAccess';
                final retryRes = await dio.fetch(e.requestOptions);
                return handler.resolve(retryRes);
              } catch (_) {
                // Refresh ham ishlamasa qayta login talab qilinadi
              }
            }
          }
          return handler.next(e);
        },
      ),
    );
  }

  Future<Response> pinLogin(String pin, {String? branchId}) {
    return dio.post('/auth/login/pin/', data: {
      'pin': pin,
      if (branchId != null) 'branch_id': branchId,
    });
  }
}

import 'package:go_router/go_router.dart';
import 'package:restopro/features/auth/presentation/device_setup_screen.dart';
import 'package:restopro/features/auth/presentation/pin_login_screen.dart';
import 'package:restopro/features/pos/presentation/pos_main_screen.dart';

final appRouter = GoRouter(
  initialLocation: '/setup',
  routes: [
    GoRoute(
      path: '/setup',
      builder: (context, state) => const DeviceSetupScreen(),
    ),
    GoRoute(
      path: '/login',
      builder: (context, state) => const PinLoginScreen(),
    ),
    GoRoute(
      path: '/pos',
      builder: (context, state) => const PosMainScreen(),
    ),
  ],
);
